import bpy
import os
import numpy as np
import zlib
import time
from mathutils import Vector, Color, Matrix, Euler, Quaternion
from bpy.props import BoolProperty, BoolVectorProperty, IntProperty, IntVectorProperty, FloatProperty, FloatVectorProperty, StringProperty, EnumProperty, PointerProperty, CollectionProperty
from struct import pack as Pack
from struct import unpack as Unpack

PackChars = lambda s: b''.join([Pack('B', ord(c)) for c in s])
PackString = lambda s: b''.join([Pack('B', ord(c)) for c in s]) + Pack('B', 0)
PackVector = lambda k,v: b''.join([Pack(k,x) for x in v])
PackMatrix = lambda m: b''.join([Pack('ffff', *tuple(v)) for v in m.copy().transposed().copy()])

HexString = lambda value,n=8: "".join("0123456789ABCDEF"[(value>>(i*4)) & 0xF] for i in range(0, n))[::-1]

classlist = []

"======================================================================================================"
"CONSTANTS"
"======================================================================================================"

MODEL_NULLINDEX = 255

VBM_SCRIPTISEXPORTING = 'VBM_EXPORTING'     # Set in active scene before running pre and post script mesh code

VBM_FILEEXT = ".vbm"

VBM_LAYERMASKSIZE = 32
VBM_LAYERMASKICON = 'INFO'
VBM_MESHTYPES = ('MESH', 'CURVE')

VBM_EXPORTENABLEDICONS = ('CHECKBOX_DEHLT', 'CHECKBOX_HLT', 'CHECKMARK')
VBM_ICON_SWING = 'CON_SPLINEIK'

VBM_VTX_COMPRESSED = 1<<0

VBM_BONEFLAGS_HIDDEN = (1<<0)
VBM_BONEFLAGS_SWINGBONE = (1<<1)
VBM_BONEFLAGS_HASPROPS = (1<<2)

VBM_MATERIALFLAGS_TRANSPARENT = (1<<0)
VBM_MATERIALFLAGS_USECULLING = (1<<1)

VBM_TEXTUREFLAG_FILTERLINEAR = (1<<1)
VBM_TEXTUREFLAG_EXTEND = (1<<2)

VBM_ANIMATIONFLAGS_CURVENAMES = (1<<0)
VBM_ANIMATIONFLAGS_CURVELOOP = (1<<1)
VBM_ANIMATIONFLAGS_MARKERS = (1<<2)

VFORMATDATA = (     # (name, size, space, icon)
    ('POS', 3, 12, 'EMPTY_ARROWS'),
    ('NOR', 3, 12, 'NORMALS_VERTEX'),
    ('TAN', 3, 12, 'NORMALS_VERTEX_FACE'),
    ('BTN', 3, 12, 'MOD_NORMALEDIT'),
    ('COL', 4,  4, 'GROUP_VCOL'),
    ('UVS', 2,  8, 'UV'),
    ('UV2', 2,  8, 'GROUP_UVS'),
    ('BON', 4, 16, 'BONE_DATA'),
    ('WEI', 4, 16, 'MOD_VERTEX_WEIGHT'),
    ('GRO', 4,  4, 'GROUP_VERTEX'),
)

VFORMAT_NAME = [x[0] for x in VFORMATDATA]
VFORMAT_ELEMENTS = [x[1] for x in VFORMATDATA]
VFORMAT_INDEX = {k: i for i,k in enumerate(VFORMAT_NAME)}
VFORMAT_SPACE = [x[2] for x in VFORMATDATA]
VFORMAT_ICON = [x[3] for x in VFORMATDATA]

VFORMAT_DEFAULTMASK = sum([
    ((1<<i) * (VFORMAT_NAME[i] in 'POS COL UVS'.split())) | ((1<<(i+16)) * (VFORMAT_NAME[i] in ['COL']))
    for i in range(0,10)
])

Items_Framerate = tuple([ (str(i),str(i)+" FPS",str(i)+" FPS", 'NONE', i) for i in range(1,61) if (60/i)==float(60//i) ])
Items_LayermaskSize = tuple([ (str(i),str(i),str(i), 'NONE', i) for i in (8,16,32) ])

"======================================================================================================"
"FUNCTIONS"
"======================================================================================================"

def CalcStride(format_mask):
    stride = 0
    for i in range(0, 16):
        if format_mask & (1<<i):
            is_bytes = (format_mask & (1<<(i+16))) != 0
            stride += (4) if is_bytes else (VFORMAT_ELEMENTS[i] * 4)
    return stride

def ActiveCollection():
    return bpy.context.collection

def CollectionRig(collection=None):
    if not collection:
        collection=ActiveCollection()
    return ([x for x in collection.all_objects if x.type=='ARMATURE' and x.children]+[None])[0]

def FixName(name):
    return "".join([x if x.lower() in "qwertyuiopasdfghjklzxcvbnm1234567890" else "_" for x in name.replace('DEF-', "")])

def ValidName(name):
    return name[0].lower() in "qwertyuiopasdfghjklzxcvbnm1234567890" and (name[:4] != 'WGTS')

def MaskVectorStr(maskboolvector):
    return "0b"+"".join(["01"[x] for i,x in enumerate(maskboolvector[:int(bpy.context.scene.vbm.layermask_display_size)])])

LayerCollections = lambda c, outdict: (outdict.update({c.name: c}), [LayerCollections(child, outdict) for child in c.children], outdict)[-1] 
LayerCollection = lambda c: LayerCollections(bpy.context.view_layer.layer_collection, {})[c.name]
def SelectCollection(collection):
    bpy.context.view_layer.active_layer_collection = LayerCollections(bpy.context.view_layer.layer_collection, {})[collection.name]
    
# ..........................................................................
def EvaluateDeformOrder(skeleton_object):
    if not skeleton_object:
        return ([], {}, {})
    
    # All -> Deform Only
    deformmap = {}
    deformbones = [b for b in skeleton_object.data.bones if b.use_deform]
    for b in deformbones:
        p = b.parent
        usedparents = []
        if p and not p.use_deform:
            while p and not p.use_deform:
                usedparents.append(p)
                d = skeleton_object.data.bones.get(p.name.replace('ORG-', 'DEF-'))
                p = d if (d and d != b and (d.use_deform or d not in usedparents)) else p.parent
        deformmap[b.name] = p.name if p else None
    
    # Calculate order based on parents
    deformorder = []
    DeformWalk = lambda bname: (deformorder.append(bname), [DeformWalk(child) for child in [k for k,p in list(deformmap.items()) if p==bname]])
    [DeformWalk(bname) for bname,p in deformmap.items() if not p]
    
    # Sort by depth to minimize parent switches
    BoneDepth = lambda bname, deformmap: (1+BoneDepth(deformmap[bname], deformmap)) if deformmap[bname] else 0
    deformlist = list(deformorder)
    deformlist.sort(key=lambda bname: BoneDepth(bname, deformmap))
    
    skeleton_object.vbm['DEFORM_MAP'] = {bname: (deformmap[bname] if deformmap.get(bname, None) else None) for bname in deformorder} # {bonename: parentname}
    skeleton_object.vbm['DEFORM_LIST'] = deformlist   # [0, first_bone, second_bone, ...]
    skeleton_object.vbm['DEFORM_ROUTE'] = {bname: bname for bname in deformorder}    # {sourcename: bonename}
    return (list(skeleton_object.vbm['DEFORM_LIST']), skeleton_object.vbm['DEFORM_MAP'], skeleton_object.vbm['DEFORM_ROUTE'])

"======================================================================================================"
"STRUCTS"
"======================================================================================================"

class VBM_PG_Label(bpy.types.PropertyGroup):
    pass
classlist.append(VBM_PG_Label)

class VBM_PG_CollectionItem(bpy.types.PropertyGroup):
    collection: PointerProperty(type=bpy.types.Collection, options=set())
    depth: IntProperty(min=0, default=0, options=set())
classlist.append(VBM_PG_CollectionItem)

class VBM_PG_ActionItem(bpy.types.PropertyGroup):
    action: PointerProperty(name="Action", type=bpy.types.Action, description="Action")
    export_enabled: BoolProperty(name="Export Enabled", default=1, options=set(), description="Include action on export")
classlist.append(VBM_PG_ActionItem)

# ---------------------------------------------------------------------------------------------------------
class VBM_PG_Image(bpy.types.PropertyGroup):
    def get_image(self):
        return [x for x in bpy.data.images if x.vbm == self][0]
        
    def pad_pixels(self, save=False):
        # Modified image filtering code of IMB_filter_extend() from Blender source:
        # https://github.com/blender/blender/blob/main/source/blender/imbuf/intern/filter.cc#L200
        
        image = self.get_image()
        exec_time = time.time_ns()
        w,h = image.size
        n = w*h
        iterations = max(w//8, h//8)
        
        dstpixels = np.frombuffer( ((255.0*np.array(tuple(image.pixels), dtype=np.float32)).astype(np.uint8)).tobytes(), dtype=np.uint32)
        srcpixels = []
        assigned = np.array([(x>>24) >= 255 and (x&0x00FFFFFF) != 0 for x in dstpixels])
        tmp = 0
        
        for r in range(0, iterations):
            srcpixels = dstpixels
            dstpixels = np.array(srcpixels)
            index = 0
            for index in range(0, n):
                if not assigned[index]:
                    x = index % w
                    y = index // w
                    # Check if adjacent pixels have been assigned
                    if (
                        (x-1 >=0 and assigned[y*w+(x-1)]) or
                        (x+1 < w and assigned[y*w+(x+1)]) or
                        (y-1 >=0 and assigned[(y-1)*w+x]) or
                        (y+1 < h and assigned[(y+1)*w+x])
                    ):
                        # Test around active pixel
                        for i,j in ( (-1,0), (1,0), (0,-1), (0,1) ):
                            tmpindex = (y+j)*w+(x+i)
                            if (x+i >= 0) and (x+i < w) and (y+j >= 0) and (y+j < h) and assigned[tmpindex]:
                                tmp = srcpixels[tmpindex]
                        if tmp != 0:
                            dstpixels[index] = tmp
                            assigned[index] = True
                            tmp = 0
        
        image.pixels = np.frombuffer(np.array(dstpixels, dtype=np.uint32).tobytes(), dtype=np.uint8).astype(np.float32)/255.0
    
        if save:
            if image.packed_file:
                image.pack()
            elif image.filepath:
                image.save()
classlist.append(VBM_PG_Image)

class VBM_PG_Material(bpy.types.PropertyGroup):
    def get_shader(self):
        return self.shader if self.shader else bpy.context.scene.vbm.shader_default
    shader: StringProperty(default="", description="Name of shader asset")
    transparent: BoolProperty(default=False, options=set(), description="Sets transparency flag on export")
classlist.append(VBM_PG_Material)

class VBM_PG_MaterialOverride(bpy.types.PropertyGroup):
    material: PointerProperty(type=bpy.types.Material, description="Material to replace")
    override: PointerProperty(type=bpy.types.Material, description="Material to overwrite with")
classlist.append(VBM_PG_MaterialOverride)

class VBM_PG_Action(bpy.types.PropertyGroup):
    def get_action(self):
        return [x for x in bpy.data.actions if x.vbm==self][0]
    def update_action(self, context):
        if self.get('MUTEX', 0):
            return
        self['MUTEX'] = 1
        action = self.get_action()
        frame_rate = int(self.frame_rate)
        action.frame_start = self.frame_start
        if self.frame_end:
            action.frame_end = self.frame_end
            
            rig = CollectionRig()
            if rig and rig.animation_data.action == action:
                context.scene.frame_start = int(action.frame_start)
                context.scene.frame_end = int(action.frame_end) 
        else:
            self.frame_end = int(action.frame_range[1])
        self['MUTEX'] = 0
    
    frame_start: IntProperty(min=0, update=update_action)
    frame_end: IntProperty(min=0, update=update_action)
    frame_rate: EnumProperty(items=Items_Framerate, default='60', update=update_action)
    
    clean_on_bake: BoolProperty(name="Clean On Bake", default=True, description="Cleans curves on bake to reduce frame count")
    
    layermask: BoolVectorProperty(
        name="Layer Mask", 
        size=VBM_LAYERMASKSIZE, 
        default=[True for i in range(0,VBM_LAYERMASKSIZE)],
        description="Bone curves in layer mask will be exported. Use 'Bone Groups' tab to set bone layer masks."
    )
classlist.append(VBM_PG_Action)

class VBM_PG_Object(bpy.types.PropertyGroup):
    export_enabled: BoolProperty(name="Export Enabled", default=True)
    script_id: StringProperty(name="Script ID", default="")
    is_collision: BoolProperty(name="Is Collision", default=False, options=set(), description="Export object as Prism type in file")
    layermask: BoolVectorProperty(name="Layer Mask", size=VBM_LAYERMASKSIZE, default=[i==0 for i in range(0,VBM_LAYERMASKSIZE)])
classlist.append(VBM_PG_Object)

class VBM_PG_Swingbone(bpy.types.PropertyGroup):
    name: StringProperty(default="s_bone")
    export_enabled: BoolProperty(name="Export Enabled", default=1)
    swing_enabled: BoolProperty(name="Swing Enabled", default=0)
    stiffness: FloatProperty(name="Stiffness", default=0.1, min=0.0, max=1.0, subtype='FACTOR', description="Speed that bone approaches goal")
    damping: FloatProperty(name="Damping", default=0.2, min=0.0, max=1.0, subtype='FACTOR', description="Controls particle distance from goal")
    limit: FloatProperty(name="Limit", default=0.8, min=0.0, max=1.0, subtype='FACTOR', description="Limits maximum rotation")
    force_strength: FloatProperty(name="Force Strength", default=1.0, min=0.0, max=1.0, subtype='FACTOR', description="Amount of influence by forces such as gravity")
    
    bones: CollectionProperty(name="Bones", type=VBM_PG_Label)
    bone_index: IntProperty(name="Bone Index", min=0)
    layermask: BoolVectorProperty(name="Layer Mask", size=VBM_LAYERMASKSIZE, default=[i==0 for i in range(0,VBM_LAYERMASKSIZE)])
classlist.append(VBM_PG_Swingbone)

# -----------------------------------------------------------------------------------------------------
class VBM_PG_Collection(bpy.types.PropertyGroup):
    def export(self):
        def Walk_ExportCollection(collection):
            hits = 0
            if collection.vbm.enabled:
                ExportModel(collection, report=False)
                hits += 1
            for c in collection.children:
                hits += Walk_ExportCollection(c)
            return hits
        
        collection = ActiveCollection()
        hits = Walk_ExportCollection(self.get_collection())
        SelectCollection(collection)
        return hits
    
    def refresh(self):
        sccollection = self.get_collection()
        [c.vbm.children.remove(0) for c in [sccollection]+list(sccollection.children_recursive) for i in range(0,len(c.vbm.children))]
        
        def VBMCollection_WalkRefresh(root, collection, depth):
            if root != collection:
                item = root.vbm.children.add()
                item.collection = collection
                item.depth = depth-1
                
            for c in list(collection.children):
                c.vbm.refresh()
                VBMCollection_WalkRefresh(root, c, depth+1)
        VBMCollection_WalkRefresh(sccollection, sccollection, 0)
    
    def get_collection(self):
        return ([x for x in bpy.data.collections if x.vbm==self]+[bpy.context.scene.collection])[0]
    def get_name(self):
        return self.name if self.name else self.get_collection().name
    
    def select_action(self, context):
        if self.actions:
            rig = CollectionRig(self.get_collection())
            if rig:
                action = self.actions[self.action_index].action
                rig.animation_data.action = action
                rig.animation_data.action_slot = action.slots[0]
                action.vbm.update_action(context)
    def update_pose_action(self, context):
        if self.action_pose:
            rig = CollectionRig(self.get_collection())
            if rig:
                rig.animation_data.action = self.action_pose
                rig.animation_data.action_slot = self.action_pose.slots[0]
    
    def sort_actions(self):
        order = [x.action for x in self.actions]
        order.sort(key=lambda x: x.name)
        [self.actions.move([x.action for x in self.actions].index(action), 0) for action in order[::-1]]
    
    def sort(self):
        collection = self.get_collection()
        objects = list(collection.objects)
        objects.sort(key=lambda obj: ("z" if not ValidName(obj.name[0]) else "") + obj.type + obj.name)
        [collection.objects.unlink(obj) for obj in objects]
        [collection.objects.link(obj) for obj in objects]
    
    def fix_materials(self):
        collection = self.get_collection()
        materials = list(set([mtl for obj in collection.all_objects if obj.type=='MESH' for mtl in obj.data.materials if mtl]))
        for mtl in materials:
            mtl.use_backface_culling = True
            mtl.use_backface_culling_shadow = True
            outputnode = ([nd for nd in mtl.node_tree.nodes if nd.bl_idname=='ShaderNodeOutputMaterial'])[0]
            offset = tuple(outputnode.location)
            for nd in mtl.node_tree.nodes:
                nd.location[0] -= offset[0]
                nd.location[1] -= offset[1]
            imagenodes = [nd for nd in mtl.node_tree.nodes if nd.bl_idname=='ShaderNodeTexImage' and nd.image and nd.image and ValidName(nd.image.name)]
            if len(imagenodes):
                imagenodes[0].name = "Image Texture"
    
    def get_materials(self):
        collection = self.get_collection()
        materials = list(set([mtl for obj in collection.all_objects if obj.type=='MESH' for mtl in obj.data.materials if mtl]))
        materials += [mtl for item in self.material_overrides for mtl in (item.material, item.override) if mtl]
        return list(set(materials))
    
    def get_material_override(self, material):
        for item in self.material_overrides:
            if item.material == material and item.override:
                return item.override
        return material
    
    def get_bone_layermask(self, bonename):
        layervector = self.bone_layermask_default
        for bone_group in self.bone_groups:
            if bonename in list(bone_group.bones.keys()):
                layervector = bone_group.layermask
        return int( sum([1<<i for i,x in enumerate(layervector) if x]) )
        
    def get_format(self):
        return self.format if self.format else []
    
    def update_format(self, context):
        if sum(self.format[:16]) == 0:
            format = [0]*32
            collection = self.get_collection()
            format[VFORMAT_INDEX['POS']] = 1
            format[VFORMAT_INDEX['COL']] = 1
            format[VFORMAT_INDEX['COL']+16] = 1
            format[VFORMAT_INDEX['UVS']] = 1
            
            if CollectionRig():
                format[VFORMAT_INDEX['BON']] = 1
                format[VFORMAT_INDEX['BON']+16] = 1
                format[VFORMAT_INDEX['WEI']] = 1
                format[VFORMAT_INDEX['WEI']+16] = 1
            self.format = [x > 0 for x in format]
    name: StringProperty(default="", options=set())
    
    format: BoolVectorProperty(
        name="Vertex Format", size=32, options=set(), default=tuple([((1<<i)&VFORMAT_DEFAULTMASK) != 0 for i in range(0, 32)]), update=update_format,   # [0:15] = Attribute, [16:31] = Is byte
        description="Order of vertex attributes to write buffer with:\nPosition, Normal, Tangent, Bitangent, Color, UVs, UV2, Bone, Weight, Group\n[ F ]: Float, [ B ] = Bytes\nHighlight and press [Backspace] to reset to default"
    )
    
    enabled: BoolProperty(default=False, name="Export as File")
    object_index: IntProperty(name="Object Index", default=0, min=0, options=set(), description="Exported name is the text following the last \"/\" \nEx: \"Chara/body\" -> \"body\"")
    
    actions: CollectionProperty(type=VBM_PG_ActionItem)
    action_index: IntProperty(min=0, update=select_action, options=set())
    action_pose: PointerProperty(name="Action Pose", type=bpy.types.Action, update=update_pose_action, description="Pose to export mesh with (if skinning attributes are disabled and/or rig is not present)")
    
    children: CollectionProperty(options={'HIDDEN'}, type=VBM_PG_CollectionItem)
    child_index: IntProperty(min=0, options=set())
    
    use_vtx_compression: BoolProperty(name="Compress Vertex Buffer", default=False, description="Write vertex buffer as indices to a value map, instead of a flat chunk of bytes. \nVERY SLOW.")
    use_compression: BoolProperty(name="Compress File", default=False, description="Compress file using zlib compression to reduce file size")
    
    use_material_names: BoolProperty(name="Use Mtl Names", default=False, description="Append material name to name of object on export")
    mesh_join_names: BoolProperty(name="Join Mesh Names", default=False, description="Merge meshes with similar names, after truncating name after \".\" character")
    
    color_layer_name: StringProperty(name="VC Layer Name", default="", options=set(), description="Vertex color layer to use on export. Uses 'Color' if empty")
    color_layer_default: FloatVectorProperty(name="VC Layer Default", size=4, default=(1,1,1,1), min=0, max=1.0, subtype='COLOR_GAMMA', options=set(), description="Default vertex color if vc layer name is set but not found")
    color_is_srgb: BoolProperty(name="VC sRGB", default=True, options=set(), description="Applies gamma correction to colors if true, otherwise leaves as is")
    
    uv_layer_name: StringProperty(name="UV Layer Name", default="", options=set(), description="UV layer to use on export. Uses 'UVMap' if empty")
    uv_layer_default: FloatVectorProperty(name="UV Layer Default", size=2, default=(1,1), options=set(), description="Default uv value if uv layer name is set but not found")
    
    normal_w_name: StringProperty(name="Normal.w Group", default="", options=set(), description="Vertex group to use as normal's w coordinate.")
    normal_w_value: StringProperty(name="Normal.w Value", default="", options=set(), description="Value to use as normal's w coordinate if group is not found.")
    
    object_script_pre: PointerProperty(name="Object Pre Script", type=bpy.types.Text, description="Internal python script to run before applying modifiers. \ncontext.scene['%s'] is set as a mutex before executing" % VBM_SCRIPTISEXPORTING)
    object_script_post: PointerProperty(name="Object Post Script", type=bpy.types.Text, description="Internal python script to run after applying modifiers. \ncontext.scene['%s'] is set as a mutex before executing" % VBM_SCRIPTISEXPORTING)
    
    bone_groups: CollectionProperty(name="Bone Groups", type=VBM_PG_Swingbone, options=set())
    bone_group_index: IntProperty(min=0, options=set())
    
    material_overrides: CollectionProperty(name="Material Overrides", type=VBM_PG_MaterialOverride, options=set())
    material_override_index: IntProperty(min=0, options=set())
    
    bone_layermask_default: BoolVectorProperty(
        name="Bone Layer Mask Default", 
        size=VBM_LAYERMASKSIZE, 
        default=[i==0 for i in range(0,VBM_LAYERMASKSIZE)], 
        options=set(),
        description="Default layer mask for bones not in a bone_group bone group"
    )
classlist.append(VBM_PG_Collection)

# ------------------------------------------------------------------------------
class VBM_PG_Scene(bpy.types.PropertyGroup):
    def update_datapath(self, context):
        datapath = self.data_path
        if datapath[-1] not in "/\\":
            datapath += "/"
        if datapath != self.data_path:
            self.data_path = datapath
    
    def refresh_collection(self, context):
        collection = context.scene.collection
        checksum = sum([i*ord(c) for i,x in enumerate(collection.children_recursive) for c in x.name])
        
        if checksum != self.get('VBM_CHECKSUM', -1):
            print("> VBM Collection Refresh")
            context.scene.collection.vbm.refresh()
            self['VBM_CHECKSUM'] = checksum
    
    data_path: StringProperty(name="Data Path", default="", subtype='DIR_PATH', update=update_datapath)
    layermask_display_size: EnumProperty(name="Mask Display Size", items=Items_LayermaskSize, default='8', options=set(), description="Number of layer mask bits to display")
    show_extra_info: BoolProperty(name="Extended Info", default=False, options=set(), description="Show extra info in item lists")
    shader_default: StringProperty(name="Default Shader", default="DEFAULT", options=set(), description="Default shader name for materials.")
    panel_tab: EnumProperty(default=1, update=refresh_collection, items=tuple([
        ('SCENE', "", "Scnene settings", 'PREFERENCES', 0),
        ('COLLECTION', "CLL", "Collection settings", 'OUTLINER_COLLECTION', 1),
        ('OBJECT', "OBJ", "Collection object settings", 'OBJECT_DATA', 2),
        ('MATERIAL', "MTL", "Material settings", 'MATERIAL_DATA', 3),
        ('ACTION', "ANI", "Action settings", 'ACTION', 4),
    ]))
    express_export: BoolProperty(name="Express Export", default=False)
    compress_model_files: BoolProperty(name="Compress on Export", default=False)
classlist.append(VBM_PG_Scene)

"======================================================================================================"
"OPERATORS"
"======================================================================================================"

class VBM_OT_CollectionClearChecksum(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_clear_checksum', 'VBM Clear Checksum', {'REGISTER', 'UNDO'}
    bl_description = "VBM Resets cache for group"
    group: EnumProperty(default='NONE', items=tuple([(x,x,x) for x in 'NONE OBJECT ACTION IMAGE COLLECTION ALL'.split()])) 
    def execute(self, context):
        collection = ActiveCollection()
        hits = 0
        for item in (
            [collection] if self.group == 'COLLECTION' else
            [x for x in collection.all_objects] if self.group == 'OBJECT' else
            [x.action for x in collection.vbm.actions] if self.group == 'ACTION' else
            list(set([nd.image for obj in collection.all_objects if obj.type=='MESH' for mtl in obj.data.materials if mtl for nd in mtl.node_tree.nodes if nd.bl_idname=='ShaderNodeTexImage' and nd.image])) if self.group == 'IMAGE' else
            []
        ):
            hit = 0
            for k in tuple(item.keys())[::-1]:
                if "VBM_" in k:
                    del item[k]
                    hit = 1
            for k in tuple(item.vbm.keys())[::-1]:
                if "VBM_" in k:
                    del item.vbm[k]
                    hit = 1
            hits += hit
        self.report({'INFO'}, "%d hits" % hits)
        SelectCollection(collection)
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionClearChecksum)

class VBM_OT_CollectionSortObjects(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.sort_objects', "VBM Sort Objects", {'REGISTER', 'UNDO'}
    def execute(self, context):
        ActiveCollection().vbm.sort()
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionSortObjects)

class VBM_OT_CollectionRenameObjects(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.rename_objects', "VBM Rename Objects", {'REGISTER', 'UNDO'}
    bl_description = "Renames objects to \"<collectionname>/<objectname>\" and trims chars after \".\""
    def execute(self, context):
        hits = 0
        def WalkRename(collection):
            hits = 0
            collectionname = collection.name
            for obj in collection.objects:
                nodename = obj.name.split("/")[-1]
                while nodename[0] in "!`-_.,|[]:';-=~":
                    nodename = nodename[1:]
                if obj.name[0] in "!`-_.,|[]:';-=~":
                    newname = obj.name[0] + collectionname + "/" + nodename
                else:
                    newname = collectionname + "/" + nodename
                if collection == context.scene.collection:
                    newname = nodename
                    
                if obj.name != newname:
                    obj.name = newname
                    if obj.data:
                        obj.data.name = newname
                    hits += 1
            
            for c in collection.children:
                hits += WalkRename(c)
            return hits
        collection = ActiveCollection()
        hits = WalkRename(collection)
        self.report({'INFO'}, "Hit(s) %d" % hits)
        SelectCollection(collection)
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionRenameObjects)

class VBM_OT_CollectionMoveObject(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_object_move', 'Move Object', {'REGISTER', 'UNDO'}
    bl_description = "Moves object up or down in collection"
    direction: EnumProperty(name="Direction", items=tuple([(x,x,x) for x in 'UP DOWN'.split()]))
    def execute(self, context):
        collection = ActiveCollection()
        objects = list(collection.objects)
        index = collection.vbm.object_index
        if self.direction == 'UP' and index > 0:
            order = [objects[(i-1) if i==index else (i+1) if i==index-1 else i] for i in range(0,len(objects))]
            [collection.objects.unlink(obj) for obj in objects]
            [collection.objects.link(obj) for obj in order]
            collection.vbm.object_index -= 1
        if self.direction == 'DOWN' and index < len(objects)-1:
            order = [objects[(i+1) if i==index else (i-1) if i==index+1 else i] for i in range(0,len(objects))]
            [collection.objects.unlink(obj) for obj in objects]
            [collection.objects.link(obj) for obj in order]
            collection.vbm.object_index += 1
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMoveObject)

# ---------------------------------------------------------------------------------------------------------
class VBM_OT_CollectionAddAction(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_action_add', 'Add Action', {'REGISTER', 'UNDO'}
    bl_description = "Adds action item to action list"
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.actions.add().action
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionAddAction)

class VBM_OT_CollectionPushAction(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_action_push', 'Push Action', {'REGISTER', 'UNDO'}
    bl_description = "Pushes action from active rig to action list"
    def execute(self, context):
        collection = ActiveCollection()
        rig = CollectionRig(collection)
        action = rig.animation_data.action
        if action not in [x.action for x in collection.vbm.actions]:
            collection.vbm.actions.add().action = action
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionPushAction)

class VBM_OT_CollectionRemoveAction(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_action_remove', 'Remove Action', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.actions.remove(collection.vbm.action_index)
        collection.vbm.action_index = max(0, min(collection.vbm.action_index, len(collection.vbm.actions)-1))
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionRemoveAction)

class VBM_OT_CollectionMoveAction(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_action_move', 'Move Action', {'REGISTER', 'UNDO'}
    direction: EnumProperty(name="Direction", items=tuple([(x,x,x) for x in 'UP DOWN'.split()]))
    def execute(self, context):
        collection = ActiveCollection()
        if self.direction == 'UP':
            collection.vbm.actions.move(collection.vbm.action_index, collection.vbm.action_index-1)
            collection.vbm.action_index -= 1
        if self.direction == 'DOWN':
            collection.vbm.actions.move(collection.vbm.action_index, collection.vbm.action_index+1)
            collection.vbm.action_index += 1
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMoveAction)

class VBM_OT_CollectionActionSort(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_action_sort', 'Sort Actions', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.sort_actions()
        SelectCollection(collection)
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionActionSort)

class VBM_OT_CollectionMaterialFix(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_material_fix', 'Fix Materials', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.fix_materials()
        SelectCollection(collection)
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMaterialFix)

# -----------------------------------------------------------------------------
class VBM_OT_CollectionAddBonegroup(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_add', 'Add Bone Group', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        bone_group = collection.vbm.bone_groups.add()
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionAddBonegroup)

class VBM_OT_CollectionRemoveBonegroup(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_remove', 'Remove Bone Group', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.bone_groups.remove(collection.vbm.bone_group_index)
        collection.vbm.bone_group_index = max(0, min(collection.vbm.bone_group_index, len(collection.vbm.bone_groups)-1))
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionRemoveBonegroup)

class VBM_OT_CollectionMoveBonegroup(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_move', 'Move Bone Group', {'REGISTER', 'UNDO'}
    direction: EnumProperty(name="Direction", items=tuple([(x,x,x) for x in 'UP DOWN'.split()]))
    def execute(self, context):
        collection = ActiveCollection()
        if self.direction == 'UP':
            collection.vbm.bone_groups.move(collection.vbm.bone_group_index, collection.vbm.bone_group_index-1)
            collection.vbm.bone_group_index -= 1
        if self.direction == 'DOWN':
            collection.vbm.bone_groups.move(collection.vbm.bone_group_index, collection.vbm.bone_group_index+1)
            collection.vbm.bone_group_index += 1
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMoveBonegroup)

class VBM_OT_CollectionAddBonegroupSelectedBones(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_bones_from_selected', 'Add Selected Bones to Group', {'REGISTER', 'UNDO'}
    @classmethod
    def poll(self, context):
        return context.active_object and context.active_object.type=='ARMATURE' and context.object.mode == 'POSE'
    
    def execute(self, context):
        collection = ActiveCollection()
        bone_group = collection.vbm.bone_groups[collection.vbm.bone_group_index]
        
        rig = CollectionRig(collection)
        bonenames = tuple(rig.data.bones.keys())
        for pb in context.selected_pose_bones:
            bname = pb.name
            if "DEF-"+bname.split("-")[-1] in bonenames:
                bname = "DEF-"+bname.split("-")[-1]
            elif "DEF-"+bname.split("-")[-1].replace("_ik","") in bonenames:
                bname = "DEF-"+bname.split("-")[-1].replace("_ik","")
            elif "DEF-"+bname.split("-")[-1].replace("_fk","") in bonenames:
                bname = "DEF-"+bname.split("-")[-1].replace("_fk","")
            if not ValidName(bname) or bname in list(bone_group.bones.keys()):
                continue
            b = rig.data.bones[bname]
            if b.use_deform:
                bone_group.bones.add().name = bname
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionAddBonegroupSelectedBones)

class VBM_OT_CollectionRemoveBonegroupBone(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_remove_bone', 'Remove Bone Group Bone', {'REGISTER', 'UNDO'}
    index: IntProperty(name="Index")
    def execute(self, context):
        collection = ActiveCollection()
        bone_group = collection.vbm.bone_groups[collection.vbm.bone_group_index]
        bone_group.bones.remove(self.index)
        bone_group.bone_index = max(0, min(self.index, len(bone_group.bones)-1))
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionRemoveBonegroupBone)

class VBM_OT_CollectionClearBonegroupBones(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_bonegroup_bones_clear', 'Clear Swing Bones', {'REGISTER', 'UNDO'}
    index: IntProperty(name="Index")
    def execute(self, context):
        collection = ActiveCollection()
        bone_group = collection.vbm.bone_groups[collection.vbm.bone_group_index]
        for i in range(0, len(bone_group.bones)):
            bone_group.bones.remove(0)
        bone_group.bone_index = 0
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionClearBonegroupBones)

# -----------------------------------------------------------------------------
class VBM_OT_CollectionMaterialOverrideAdd(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_material_override_add', 'Add Material Override', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.material_overrides.add()
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMaterialOverrideAdd)

class VBM_OT_CollectionMaterialOverrideRemove(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.collection_material_override_remove', 'Remove Material Override', {'REGISTER', 'UNDO'}
    def execute(self, context):
        collection = ActiveCollection()
        collection.vbm.material_overrides.remove(collection.vbm.material_override_index)
        collection.vbm.material_override_index = max(0, min(collection.vbm.material_override_index, len(collection.vbm.material_overrides)-1))
        return {'FINISHED'}
classlist.append(VBM_OT_CollectionMaterialOverrideRemove)

# ===================================================================================================
Clean = lambda: [data.remove(x) for data in (bpy.data.meshes, bpy.data.objects, bpy.data.armatures, bpy.data.images, bpy.data.actions) for x in list(data)[::-1] if x.get('TEMP', False)]

class VBM_OT_ExportCollection(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.export_collection', 'Export Collection', {'REGISTER', 'UNDO'}
    bl_description = "Exports active collection"
    def execute(self, context):
        collection = ActiveCollection()
        t = time.time_ns()
        hits = collection.vbm.export()
        SelectCollection(collection)
        if hits == 0:
            self.report({'WARNING'}, "> No collections exported. (Active collection not marked for export?)")
        else:
            self.report({'INFO'}, "> Export Complete \"%s\" (%d hit(s), %2.2f sec)" % (collection.name, hits, (time.time_ns()-t)/1_000_000_000 ))
        return {'FINISHED'}
classlist.append(VBM_OT_ExportCollection)

class VBM_OT_ExportCollectionAll(bpy.types.Operator):
    bl_idname, bl_label, bl_options = 'vbm.export_collection_all', 'Export Scene Collections', {'REGISTER', 'UNDO'}
    bl_description = "Export all collections in scene"
    def execute(self, context):
        t = time.time_ns()
        hits = context.scene.collection.vbm.export()
        if hits == 0:
            self.report({'WARNING'}, "> No collections exported")
        else:
            self.report({'INFO'}, "> Export Complete (%d hits, %2.2f sec)" % (hits, (time.time_ns()-t)/1_000_000_000))
        SelectCollection(context.scene.collection)
        return {'FINISHED'}
classlist.append(VBM_OT_ExportCollectionAll)

# ============================================================================================
class VBM_OT_TexturePadding(bpy.types.Operator):
    bl_idname, bl_label, bl_options = ('vbm.texture_apply_padding', 'VBM Texture Padding', {'REGISTER', 'UNDO'})
    bl_description = "Extend edges of pixels on texture to fill in alpha"
    
    image : bpy.props.StringProperty(name="Image", default="")
    
    def invoke(self, context, event):
        if 1 or self.image == "":
            for a in [a for a in context.screen.areas if (a.type == 'IMAGE_EDITOR' or a.type == 'UV_EDIT') and a.spaces[0].image][:1]:
                self.image = a.spaces[0].image.name
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        self.layout.prop_search(self, 'image', bpy.data, 'images')
    
    def execute(self, context):
        image = bpy.data.images.get(self.image, None)
        if image:
            image.vbm.pad_pixels()
        return {'FINISHED'}
classlist.append(VBM_OT_TexturePadding)

class VBM_OT_RigClearPose(bpy.types.Operator):
    bl_idname, bl_label, bl_options = ('vbm.rig_clear_pose', 'VBM Rig Clear Pose', {'REGISTER', 'UNDO'})
    bl_description = "Resets transforms of pose bones"
    def execute(self, context):
        rig = CollectionRig()
        if rig:
            for pb in rig.pose.bones:
                pb.location = (0,0,0)
                pb.rotation_quaternion = (1,0,0,0)
                pb.rotation_euler = (0,0,0)
                pb.scale = (1,1,1)
        return {'FINISHED'}
classlist.append(VBM_OT_RigClearPose)

"======================================================================================================"
"UILIST"
"======================================================================================================"

class VBM_UL_CollectionChildren(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        collection = item.collection
        if collection:
            numfiles = len([x for x in [collection]+list(collection.children_recursive) if x.vbm.enabled])
            layout = layout.row(align=1)
            layout.prop(collection.vbm, 'enabled', text="", icon=VBM_EXPORTENABLEDICONS[collection.vbm.enabled], emboss=False)
            r = layout.row(align=1)
            r.enabled = numfiles > 0
            
            rr = r.row(align=1)
            rr.scale_x = 0.8
            for i in range(0, item.depth):
                rr.label(text="", icon='THREE_DOTS')
            rr.label(text="", icon='TEXT' if collection.vbm.enabled else 'OUTLINER_COLLECTION' if numfiles>0 else 'GROUP')
            
            r.separator()
            r.prop(collection, 'name', text="", emboss=False)
            rr = r.row(align=1)
            rr.alignment = 'RIGHT'
            rr.label(text="%d File(s)" % numfiles)
classlist.append(VBM_UL_CollectionChildren)

# ------------------------------------------------------------------------------------------------
class VBM_UL_CollectionObjects(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout = layout.column(align=1)
        obj = item
        layout.enabled = ValidName(obj.name)
        r = layout.row(align=1)
        r.prop(obj.vbm, 'export_enabled', text="", icon=VBM_EXPORTENABLEDICONS[obj.vbm.export_enabled*(2-layout.enabled)], emboss=False)
        icon = 'OUTLINER_OB_GROUP_INSTANCE' if obj.instance_collection else (('OUTLINER_DATA_')+obj.type)
        
        if layout.enabled:
            rr = r.row(align=1)
            rr.prop(obj, 'name', text="", placeholder="(Export Name)", emboss=0, icon=icon)
            rr.active = index==data.vbm.object_index
            
            if obj.type in VBM_MESHTYPES:
                r.separator()
                r.prop(obj.vbm, 'is_collision', text="", icon='PHYSICS')
        else:
            rr = r.row(align=1)
            rr.label(text="", icon='MESH_PLANE')
            rr.scale_x = 0.09
            r.label(text="( %s )"%obj.name, icon=icon)
        
        if obj.type == 'ARMATURE':
            rr = r.row()
            rr.alignment='RIGHT'
            rr.label(text="%d" % len(obj.vbm['DEFORM_LIST'] if obj.vbm.get('DEFORM_LIST',None) else [b for b in obj.data.bones if b.use_deform]), icon='BONE_DATA')
        
        if context.scene.vbm.show_extra_info:
            r = layout.row(align=1)
            r.alignment='RIGHT'
            r.label
            r.label(text="Mask: " + MaskVectorStr(obj.vbm.layermask))
classlist.append(VBM_UL_CollectionObjects)

# -------------------------------------------------------------------------------------
class VBM_UL_CollectionActions(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        action = item.action
        layout = layout.column(align=1)
        if not action:
            r = layout.row(align=1)
            r.prop(item, 'export_enabled', text="", icon=VBM_EXPORTENABLEDICONS[item.export_enabled], emboss=False)
            r.prop(item, 'action')
            r = layout.row(align=1)
            r.label()
            r.label(text="(Action Missing)")
        else:
            r = layout.row(align=1)
            r.prop(item, 'export_enabled', text="", icon=VBM_EXPORTENABLEDICONS[item.export_enabled], emboss=False)
            rr = r.row(align=1)
            rr.active = item.export_enabled
            rr.scale_x = 1.5
            rr.prop(action, 'name', text="", emboss=False)
            
            rr = r.row(align=1)
            rr.enabled = action.use_frame_range
            rr.label(text="%02d:%02d" % (action.frame_range[0], action.frame_range[1]))
            r.prop(action.vbm, 'clean_on_bake', text="", icon='MOD_SMOOTH')
            r.separator()
            r.prop(action, 'use_frame_range', text="", icon='PREVIEW_RANGE')
            r.prop(action, 'use_cyclic', text="", icon='FILE_REFRESH')
            
            # Extended info
            if context.scene.vbm.show_extra_info:
                r = layout.row(align=1)
                r = r.row(align=1)
                r.alignment='RIGHT'
                r.label(text="Markers: %d |" % len(action.pose_markers))
                r.label(text="Mask:")
                r.label(text=MaskVectorStr(action.vbm.layermask))
classlist.append(VBM_UL_CollectionActions)

# -------------------------------------------------------------------------------------
class VBM_UL_CollectionBonegroup(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        maskstring = "".join(["`|"[x] for x in item.layermask[:8]])
        r = layout.row(align=1)
        r.prop(item, 'name', text="", icon='GROUP_BONE', emboss=False)
        rr = r.row(align=1)
        rr.alignment = 'RIGHT'
        rr.label(text="%8s %2d Bones" % (maskstring+(" " if len(item.bones) < 10 else ""), len(item.bones)) )
        r.prop(item, 'swing_enabled', text="", icon=VBM_ICON_SWING)
classlist.append(VBM_UL_CollectionBonegroup)

class VBM_UL_CollectionBonegroupBones(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        r = layout.row(align=1)
        r.label(text=item.name, icon='BONE_DATA')
        r.operator('vbm.collection_bonegroup_remove_bone', text="", icon='X', emboss=False).index=index
classlist.append(VBM_UL_CollectionBonegroupBones)

# -------------------------------------------------------------------------------------
class VBM_UL_CollectionMaterialoverride(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        r = layout.row(align=1)
        #r.prop(item, 'enabled', text="", icon='CHECKBOX_HLT' if item.enabled else 'CHECKBOX_DEHLT', emboss=False)
        r.prop(item, 'material', text="")
        r.prop(item, 'override', text="->")
classlist.append(VBM_UL_CollectionMaterialoverride)

"======================================================================================================"
"PANELS"
"======================================================================================================"

# ---------------------------------------------------------------------------------------
def VBMDrawLayermask(layout, id, propname, text=""):
    n = int(bpy.context.scene.vbm.layermask_display_size)
    w = bpy.context.region.width
    c = layout.column(align=1)
    if text:
        r = c.row(align=1)
        r.label(text=text+":")
        r = r.row(align=1)
        r.alignment = 'RIGHT'
        r.label(text= "".join(["`|"[x] for x in getattr(id, propname)][:n] ))
    if n <= 16:
        r = c.row(align=1)
        if n ==16 and w < 350:
            [r.prop(id, propname, text=str(i)[-1], index=i, toggle=1) for i in range(0,n)]
        else:
            [r.prop(id, propname, text="%02d"%i, index=i, toggle=1) for i in range(0,n)]
    else:
        for i in range(0,n):
            if (i%(n//2))==0:
                r = c.row(align=1)
            if n > 16 and w < 350:
                r.prop(id, propname, text=str(i)[-1], index=i, toggle=1)
            else:
                r.prop(id, propname, text="%02d"%i, index=i, toggle=1)

# ---------------------------------------------------------------------------------------
def VBMActionPanel(layout, collection):
    context = bpy.context
    
    rig = CollectionRig(collection)
    if rig:
        r = layout.row()
        r.label(text=rig.name, icon='ARMATURE_DATA')
        r.operator('vbm.rig_clear_pose', text="", icon='MOD_ARMATURE')
        layout.template_ID(rig.animation_data, 'action')
        
    r = layout.box().row()
    if collection.vbm.action_pose:
        rr = r.row()
        rr.scale_x = 0.5
        rr.label(text="Pose:")
        r.prop(collection.vbm, 'action_pose', text="")
        #r.template_ID(collection.vbm, 'action_pose', text="")
    else:
        r.prop(collection.vbm, 'action_pose')
    
    r = layout.row(align=1)
    c = r.column(align=1)
    c.scale_y = 0.7
    c.template_list('VBM_UL_CollectionActions', "", collection.vbm, 'actions', collection.vbm, 'action_index', rows=9)
    c = r.column(align=1)
    c.scale_y = 0.8
    c.prop(context.scene.vbm, 'show_extra_info', text="", icon=VBM_LAYERMASKICON)
    c.separator()
    c.operator('vbm.collection_action_push', text="", icon='NLA_PUSHDOWN')
    c.operator('vbm.collection_action_add', text="", icon='ADD')
    c.operator('vbm.collection_action_remove', text="", icon='REMOVE')
    c.separator()
    c.operator('vbm.collection_action_move', text="", icon='TRIA_UP').direction='UP'
    c.operator('vbm.collection_action_move', text="", icon='TRIA_DOWN').direction='DOWN'
    c.separator()
    c.operator('vbm.collection_action_sort', text="", icon='SORTSIZE')
    c.operator('vbm.collection_clear_checksum', text="", icon='UNLINKED').group='ACTION'
    
    if collection.vbm.actions:
        actionitem = collection.vbm.actions[collection.vbm.action_index]
        action = actionitem.action
        c = layout.column(align=0)
        if not action:
            c.prop(actionitem, 'action', text="Action")
        else:
            VBMDrawLayermask(c, action.vbm, 'layermask', "Bone Mask")
            
            r = c.row(align=0)
            r.prop(action, 'use_frame_range', text="", icon='PREVIEW_RANGE')
            r.prop(action, 'use_cyclic', text="", icon='FILE_REFRESH')
            r = r.row(align=1)
            r.enabled = action.use_frame_range
            r.prop(action.vbm, 'frame_start', text="Start")
            r.prop(action.vbm, 'frame_end', text="End")
            rr = r.row(align=0)
            rr.scale_x = 0.85
            #rr.prop(action.vbm, 'frame_rate', text="")

# ------------------------------------------------------------------------------------
class VBM_PT_Rig3DView(bpy.types.Panel):
    bl_label, bl_space_type, bl_region_type = ("DmrVBM Rig", 'VIEW_3D', 'UI')
    bl_category = "DmrVBM"
    
    def draw(self, context):
        layout = self.layout
        collection = ActiveCollection()
        rig = CollectionRig(collection)
        
        if not rig:
            layout.label(text=collection.name, icon='GROUP')
            layout.label(text="(No Armature Selected)")
        else:
            c = layout.column(align=1)
            c.scale_y = 0.8
            c.label(text=collection.name, icon='GROUP')
            r = c.row(align=1)
            r.label(text=rig.name, icon='ARMATURE_DATA')
            rr = r.row()
            rr.scale_x = 0.3
            rr.prop(rig.data, 'pose_position', expand=True)
classlist.append(VBM_PT_Rig3DView)

class VBM_PT_Rig3DView_Actions(bpy.types.Panel):
    bl_label, bl_space_type, bl_region_type = ("Actions", 'VIEW_3D', 'UI')
    bl_parent_id = 'VBM_PT_Rig3DView'
    #bl_category = "DmrVBM"
    
    def draw(self, context):
        VBMActionPanel(self.layout, ActiveCollection())
classlist.append(VBM_PT_Rig3DView_Actions)

class VBM_PT_Rig3DView_Swingbones(bpy.types.Panel):
    bl_label, bl_space_type, bl_region_type, bl_options = ("Bone Groups", 'VIEW_3D', 'UI', {'DEFAULT_CLOSED'})
    bl_parent_id = 'VBM_PT_Rig3DView'
    #bl_category = "DmrVBM"
    
    def draw(self, context):
        layout = self.layout
        collection = ActiveCollection()
        rig = CollectionRig(collection)
        
        if rig:
            deformbones = rig.get('DEFORM_LIST', None)
            if not deformbones:
                deformbones = [b for b in rig.data.bones if b.use_deform]
            
            c = layout.column(align=1)
            r = c.row(align=1)
            r.label(text="Default Layer Mask:")
            r = r.row(align=1)
            r.alignment='RIGHT'
            r.label(text="(%3d) Bones" % (len(deformbones)))
            VBMDrawLayermask(c, collection.vbm, 'bone_layermask_default', text="")
            
            r = layout.row(align=1)
            c = r.column(align=1)
            c.scale_y = 0.9
            c.template_list('VBM_UL_CollectionBonegroup', "", collection.vbm, 'bone_groups', collection.vbm, 'bone_group_index', rows=6)
            c = r.column(align=1)
            c.scale_y = 1.0
            c.operator('vbm.collection_bonegroup_add', text="", icon='ADD')
            c.operator('vbm.collection_bonegroup_remove', text="", icon='REMOVE')
            c.separator()
            c.operator('vbm.collection_bonegroup_move', text="", icon='TRIA_UP').direction='UP'
            c.operator('vbm.collection_bonegroup_move', text="", icon='TRIA_DOWN').direction='DOWN'
            c.separator()
            c.prop(context.scene.vbm, 'show_extra_info', text="", icon=VBM_LAYERMASKICON)
            
            bone_group = collection.vbm.bone_groups[collection.vbm.bone_group_index] if collection.vbm.bone_groups else None
            if bone_group:
                b = layout.box().column(align=0)
                b.active = bone_group.export_enabled
                
                VBMDrawLayermask(b, bone_group, 'layermask', text="Layer Mask")
                
                r = b.row(align=1)
                c = r.column(align=1)
                c.scale_y = 0.7
                c.template_list('VBM_UL_CollectionBonegroupBones', "", bone_group, 'bones', bone_group, 'bone_index', rows=6)
                c = r.column(align=1)
                c.scale_y = 1.0
                c.operator('vbm.collection_bonegroup_bones_from_selected', text="", icon='RESTRICT_SELECT_OFF')
                c.operator('vbm.collection_bonegroup_bones_clear', text="", icon='X')
                
                b.separator()
                c = b.box().column(align=0)
                c.prop(bone_group, 'swing_enabled', icon=VBM_ICON_SWING)
                c = c.column(align=1)
                c.active = bone_group.swing_enabled
                c.scale_y = 0.9
                c.use_property_split = True
                c.prop(bone_group, 'stiffness')
                c.prop(bone_group, 'damping')
                c.prop(bone_group, 'limit')
                c.prop(bone_group, 'force_strength')
classlist.append(VBM_PT_Rig3DView_Swingbones)

# -----------------------------------------------------------------------------------------------------------
class VBM_PT_Asset(bpy.types.Panel):
    bl_label, bl_space_type, bl_region_type = ("DmrVBM v1.5", 'PROPERTIES', 'WINDOW')
    bl_context = "scene"
    
    def draw(self, context):
        layout = self.layout
        vbm = context.scene.vbm
        collection = ActiveCollection()
        sc = context.scene
        obj = context.active_object
        
        # Collection ...............................................
        r = layout.row(align=1)
        r.prop(vbm, 'data_path', placeholder="(.blend folder)")
        
        r = layout.row(align=1)
        r.prop(collection.vbm, 'enabled', text="")
        r.label(text=collection.name, icon='GROUP')
        rr = r.row(align=1)
        rr.alignment = 'RIGHT'
        rr.label(text="%d File(s)" % (collection.vbm.enabled + len([1 for c in collection.children_recursive if c.vbm.enabled])) )
        
        r = layout.row(align=0)
        r.operator('vbm.export_collection', text="Export Collection" if collection.vbm.enabled else "Export Collection Files", icon='EXPORT')
        r = r.row()
        r.scale_x = 0.8
        r.operator('vbm.export_collection_all', text="Export All", icon='EXPORT')
        
        # Tab ----------------------------------------------------
        layout = layout.box().column(align=1)
        layout.row(align=1).prop(context.scene.vbm, 'panel_tab', expand=True)
        layout = layout.box().column(align=0)
        export_enabled = collection.vbm.enabled
        
        # Settings --------------------------------------------------------
        if context.scene.vbm.panel_tab == 'SCENE':
            c = layout.column()
            c.use_property_split = 1
            c.prop(context.scene.vbm, 'shader_default')
            c.prop(context.scene.vbm, 'layermask_display_size', text="Layer Mask Size")
            c.prop(context.scene.vbm, 'show_extra_info', text="Show Mask in List")
            
            r = layout.row(align=1)
            r.label(text="Clear Checksum:", icon='UNLINKED')
            rr = r.row(align=1)
            rr.scale_x = 0.6
            rr.operator('vbm.collection_clear_checksum', text="CLL").group='COLLECTION'
            rr.operator('vbm.collection_clear_checksum', text="OBJ").group='OBJECT'
            rr.operator('vbm.collection_clear_checksum', text="ANI").group='ACTION'
            rr.operator('vbm.collection_clear_checksum', text="TEX").group='IMAGE'
            
            layout.separator()
            c = layout.column(align=1)
            c.scale_y = 0.7
            c.template_list('VBM_UL_CollectionChildren', "", sc.collection.vbm, 'children', sc.collection.vbm, 'child_index', rows=6 if sc.collection.children else 2)
        # Collection -----------------------------------------------------
        elif context.scene.vbm.panel_tab == 'COLLECTION':
            # Active Collection
            layout.active = collection.vbm.enabled
            
            r = layout.row(align=1)
            r.prop(collection.vbm, 'enabled', text="")
            r.prop(collection.vbm, 'name', text="", icon='GROUP', placeholder=collection.name+".vbm")
            rr = r.row(align=1)
            rr.alignment = 'RIGHT'
            rr.label(text="%d File(s)" % (collection.vbm.enabled + len([1 for c in collection.children_recursive if c.vbm.enabled])) )
            
            layout.prop(collection.vbm, 'use_compression')
            
            # Format
            format = collection.vbm.format
            b = layout.row(align=1)
            b.label(text="Format:")
            c = b.column(align=1)
            
            r = c.row(align=1)
            for i,attribute_name in enumerate(VFORMAT_NAME):
                p = r.column(align=1)
                active = format[i]
                isbyte = format[i+16]
                p.prop(collection.vbm, 'format', text="", index=i, icon=VFORMAT_ICON[i], emboss=active, invert_checkbox=0)
                p.prop(collection.vbm, 'format', text="", index=i+16, icon=('EVENT_B' if isbyte else 'EVENT_F'), emboss=active, invert_checkbox=0)
            
            r = layout.row(align=1)
            r.scale_y = 0.9
            c = [r.column(align=0) for i in range(0,4)]
            c[1].scale_x = 1.5
            c[2].scale_x = 0.6
            
            e = [x.row(align=1) for x in c]
            e[0].label(text="Color", icon=VFORMAT_ICON[VFORMAT_INDEX['COL']])
            if obj and obj.type=='MESH':
                e[1].prop_search(collection.vbm, 'color_layer_name', obj.data, 'color_attributes', text="", results_are_suggestions=True)
            else:
                e[1].prop(collection.vbm, 'color_layer_name', text="", placeholder="<Active VC Layer>")
            e[2].prop(collection.vbm, 'color_layer_default', text="")
            e[3].prop(collection.vbm, 'color_is_srgb', text="", icon='MOD_THICKNESS')
            
            e = [x.row(align=1) for x in c]
            e[0].label(text="UV", icon=VFORMAT_ICON[VFORMAT_INDEX['UVS']])
            if obj and obj.type=='MESH':
                e[1].prop_search(collection.vbm, 'uv_layer_name', obj.data, 'uv_layers', text="", results_are_suggestions=True)
            else:
                e[1].prop(collection.vbm, 'uv_layer_name', text="", placeholder="<Active UV Layer>")
            e[2].row().prop(collection.vbm, 'uv_layer_default', text="")
            layout.separator()
            
            # Children
            c = layout.column(align=1)
            c.scale_y = 0.7
            c.template_list('VBM_UL_CollectionChildren', "", collection.vbm, 'children', collection.vbm, 'child_index', rows=6 if collection.children else 2)
            
        # Objects ----------------------------------------------------------
        elif context.scene.vbm.panel_tab == 'OBJECT':
            r = layout.row()
            r.label(text="", icon='TEXT')
            r.prop(collection.vbm, 'object_script_pre', text="Pre")
            r.prop(collection.vbm, 'object_script_post', text="Post")
            
            r = layout.row()
            r.active = export_enabled
            #r.prop(context.scene.vbm, 'express_export', text="", icon='FF')
            r.prop(collection.vbm, 'use_material_names')
            r.prop(collection.vbm, 'mesh_join_names', text="Join Names")
            r.prop(collection.vbm, 'use_vtx_compression', text="Compress VB")
            
            r = layout.row(align=1)
            c = r.column()
            c.active = export_enabled
            c.scale_y = 0.7
            c.template_list('VBM_UL_CollectionObjects', "", collection, 'all_objects', collection.vbm, 'object_index', rows=8)
            c = r.column(align=1)
            c.prop(context.scene.vbm, 'show_extra_info', text="", icon=VBM_LAYERMASKICON)
            c.separator()
            c.operator('vbm.collection_object_move', text="", icon='TRIA_UP').direction='UP'
            c.operator('vbm.collection_object_move', text="", icon='TRIA_DOWN').direction='DOWN'
            c.separator()
            c.operator('vbm.sort_objects', text="", icon='SORTSIZE')
            c.operator('vbm.collection_clear_checksum', text="", icon='UNLINKED').group='OBJECT'
            
            if collection.all_objects:
                obj = collection.all_objects[collection.vbm.object_index]
                b = layout.column(align=1)
                b.label(text=obj.name, icon=obj.type+"_DATA")
                VBMDrawLayermask(b, obj.vbm, 'layermask', "Object Layer Mask")
                
                c = b.column(align=1)
                c.use_property_split = True
                c.prop(obj.vbm, 'export_enabled')
                c.prop(obj.vbm, 'is_collision')
            
        # Material ----------------------------------------------------------
        elif context.scene.vbm.panel_tab == 'MATERIAL':
            materials = collection.vbm.get_materials()
            materials.sort(key=lambda mtl: mtl.name)
            
            r = layout.row()
            r.operator('vbm.collection_material_fix', icon='MODIFIER')
            r.operator('vbm.texture_apply_padding', icon='CON_SIZELIMIT')
            
            # Overrides
            r = layout.row(align=1)
            c = r.column()
            c.scale_y = 0.8
            c.template_list('VBM_UL_CollectionMaterialoverride', "", collection.vbm, 'material_overrides', collection.vbm, 'material_override_index', rows=4)
            c = r.column(align=1)
            c.operator('vbm.collection_material_override_add', text="", icon='ADD')
            c.operator('vbm.collection_material_override_remove', text="", icon='REMOVE')
            c.separator()
            c.operator('vbm.collection_clear_checksum', text="", icon='UNLINKED').group='IMAGE'
            layout.separator()
            
            # Object Materials
            b = layout.row(align=0)
            r = b.row(align=1)
            r.scale_y=0.8
            c = [r.column(align=1) for i in (0,1,2,3,4)]
            c[0].scale_x = 1.1
            c[1].scale_x = 0.8
            c[2].scale_x = 1.2
            c[0].label(text="MTL", icon='MATERIAL')
            c[1].label(text="SHD", icon='CONSOLE')
            c[2].label(text="TEX", icon='NODE_TEXTURE')
            c[3].label(text="", icon='IMAGE_ALPHA')
            c[4].label(text="", icon='ORIENTATION_NORMAL')
            for mtl in materials:
                c[0].prop(mtl, 'name', text="")
                c[1].prop(mtl.vbm, 'shader', text="", placeholder=mtl.vbm.get_shader())
                ndimage = mtl.node_tree.nodes.get("Image Texture", None)
                if ndimage:
                    c[2].prop(ndimage, 'image', text="")
                else:
                    c[2].label(text="(No Image)")
                c[3].prop(mtl.vbm, 'transparent', text="", icon='CHECKBOX_HLT' if mtl.vbm.transparent else 'CHECKBOX_DEHLT', emboss=True)
                c[4].prop(mtl, 'use_backface_culling', text="", icon='CHECKBOX_HLT' if mtl.use_backface_culling else 'CHECKBOX_DEHLT', emboss=True)
        # Action
        elif context.scene.vbm.panel_tab == 'ACTION':
            VBMActionPanel(layout, collection)
classlist.append(VBM_PT_Asset)

"================================================================================================================================================="
"EXPORT"
"================================================================================================================================================="

def MeshData(src, apply_transform=False, rig=None, action_pose=None, object_script_pre=None, object_script_post=None):
    checksum_key = (
        (action_pose.name if action_pose else "") + 
        (("%4d"%len(rig.data.bones)) if rig else "") + 
        (object_script_pre.name if object_script_pre else "") + 
        (object_script_post.name if object_script_post else "")
    )
    checksum = sum(tuple(np.array([x for x in (
        (
            (
                [x for s in src.data.splines for p in s.points for x in p.co]
            ) if src.type=='CURVE' else
            (
                [x for v in src.matrix_local for x in v] +
                [x for v in src.data.vertices for x in v.co] +
                [vge.weight for v in src.data.vertices for vge in v.groups] +
                [ord(x) for mtl in src.data.materials if mtl for x in mtl.name] +
                [x for lyr in src.data.color_attributes for v in lyr.data for x in v.color] +
                [x for lyr in src.data.uv_layers for v in lyr.uv for x in tuple(v.vector)]
            ) if src.type == 'MESH' else []
        ) +
        [ord(x) for m in src.modifiers if ValidName(m.name) for x in m.name]+
        [v for m in src.modifiers if ValidName(m.name) for v in [getattr(m,p.identifier) for p in m.bl_rna.properties if not p.is_readonly] if isinstance(v, (bool,int,float))]+
        ([i*ord(x) for i,bname in enumerate(EvaluateDeformOrder(src.find_armature())[0]) for x in bname] if src.find_armature() else [])+
        ([x for fc in action_pose.fcurves for k in fc.keyframe_points for x in k.co] if action_pose else [])+
        ([ord(c) for script in [object_script_pre, object_script_post] if script for line in script.lines for c in line.body])+
        [apply_transform]
        )
    ]).tobytes()))
    
    if int(src.vbm.get('VBM_CHECKSUM'+checksum_key, -1)) != checksum or not src.vbm.get('VBM_DATA'+checksum_key, {}):
        print("> Building mesh \"%s\"..." % src.name, action_pose.name if action_pose else "",  "(Checksum = %d)" % checksum)
        
        # Staging ............................................................................................
        context = bpy.context
        obj = src.copy()
        obj.data = src.data.copy()
        obj['TEMP'] = True
        obj.data['TEMP'] = True
        obj.name = "(VBMtemp)-"+obj.name
        obj.data.name = "(VBMtemp)-"+obj.data.name
        
        [c.objects.unlink(obj) for c in list(obj.users_collection)]
        [x.select_set(False) for x in list(context.selected_objects)]
        context.scene.collection.objects.link(obj)
        context.view_layer.objects.active = obj
        obj.select_set(True)
        
        use_skinning = rig != None
        rig = obj.find_armature()
        
        # Action Pose
        if rig:
            if action_pose:
                if not rig.animation_data:
                    rig.animation_data_create()
                rig.data.pose_position = 'POSE'
                rig.animation_data.action = action_pose
                rig.animation_data.action_slot = action_pose.slots[0]
                context.scene.frame_set(context.scene.frame_current)
        
        if apply_transform:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        def MeshScript(script, errortext):
            if script:
                context.scene[VBM_SCRIPTISEXPORTING] = True
                obj.data.update()
                err = ""
                try:
                    exec(script.as_string(), {})
                except SyntaxError as err:
                    print(errortext)
                    print(err.lineno, err.args[0])
                context.scene[VBM_SCRIPTISEXPORTING] = False
                context.view_layer.objects.active = obj
                obj.select_set(True)
        
        # Pre Script
        MeshScript(object_script_pre, "> VBM: Error executing object Pre Script (%s)" % str(object_script_pre))
        
        # Apply modifiers
        use_skinning = use_skinning and not action_pose
        for m in list(obj.modifiers):
            if not ValidName(m.name) or (m.type=='ARMATURE' and use_skinning):
                bpy.ops.object.modifier_remove(modifier=m.name)
            else:
                try:
                    bpy.ops.object.modifier_apply(modifier=m.name)
                except:
                    print(src.name, m.type, m.name)
                    #bpy.ops.object.modifier_remove(modifier=m.name)
        obj.modifiers.new(name='TRIANGULATE', type='TRIANGULATE').keep_custom_normals=True
        
        bpy.ops.object.convert(target='MESH')
        obj.data.calc_tangents()
        obj.parent = None
        context.view_layer.objects.active = obj
        
        if "UVMap" not in list(obj.data.uv_layers.keys()):
            obj.data.uv_layers.new(name="UVMap")
        if "Color" not in list(obj.data.color_attributes.keys()):
            lyr = obj.data.color_attributes.new(name="Color", type='BYTE_COLOR', domain='CORNER')
            lyr.data.foreach_set('color', np.ones(len(lyr.data)*4))
        
        # Post Script
        MeshScript(object_script_post, "> VBM: Error executing object Post Script (%s)" % str(object_script_post))
        
        # Data .........................................................................................................
        uvlyr = obj.data.uv_layers.get("UVMap", obj.data.uv_layers[0])
        vclyr = obj.data.color_attributes[obj.data.color_attributes.render_color_index]
        uvdata = [tuple((uv.vector[0], 1-uv.vector[1])) for uv in uvlyr.uv]
        vcdata = [tuple(vc.color) for vc in vclyr.data]
        if sum([x for v in vcdata for x in v]) == 0:
            vcdata = [(1,1,1,1) for v in vcdata]
        
        deformorder, deformmap, deformroute = EvaluateDeformOrder(rig)
        bonemap = {vg.index: deformorder.index(vg.name) for vg in obj.vertex_groups if vg.name in deformorder}
        skinning = [ [ (bonemap[vge.group], vge.weight) for vge in v.groups if vge.weight > 0.0 and vge.group in list(bonemap.keys())] for v in obj.data.vertices ]
        [v.sort(key=lambda x: -x[1]) for v in skinning]  # Sort by weight
        skinning = [ (x+[(0,0.0), (0,0.0), (0,0.0), (0,0.0)])[:4] for x in skinning ]    # Add padding, Clamp to 4
        skinning = [ [(b,w/s) for b,w in v[:4]] for v in skinning for s in [sum([w for b,w in v[:4]])+0.00000001] ] # Normalize weights
        
        # Compose ..............................................................................................................
        verts, loops, tris = tuple(obj.data.vertices), tuple(obj.data.loops), tuple(obj.data.loop_triangles)
        vgoutline = obj.vertex_groups.get('OUTLINEWEIGHT', None).index if 'OUTLINEWEIGHT' in list(obj.vertex_groups.keys()) else -1
        otdata = (np.array([([vge.weight for vge in v.groups if vge.group == vgoutline]+[1.0])[0] for v in verts])*255.0).astype(np.uint8)
        
        mtlvbs = {}
        material_count = len(obj.data.materials)
        material_indices = list(range(0, material_count)) if material_count > 0 else [0]
        for material_index in material_indices:
            mtl = obj.data.materials[material_index] if material_count > 0 else None
            mtlloops = [l for p in tris if p.material_index == material_index for l in p.loops]
            if mtlloops:
                mtlname = mtl.name if mtl else ""
                if mtlname not in mtlvbs:
                    mtlvbs[mtlname] = {k:b'' for k in VFORMAT_NAME}
                
                mtlvbs[mtlname]['POS'] += b''.join([PackVector('f', verts[loops[l].vertex_index].co) for l in mtlloops])
                mtlvbs[mtlname]['COL'] += b''.join([PackVector('B', [int(x*255) for x in vcdata[l]]) for l in mtlloops])
                mtlvbs[mtlname]['UVS'] += b''.join([PackVector('f', uvdata[l]) for l in mtlloops])
                mtlvbs[mtlname]['NOR'] += b''.join([PackVector('f', loops[l].normal) for l in mtlloops])
                mtlvbs[mtlname]['TAN'] += b''.join([PackVector('f', loops[l].tangent) for l in mtlloops])
                mtlvbs[mtlname]['BTN'] += b''.join([PackVector('f', loops[l].bitangent) for l in mtlloops])
                mtlvbs[mtlname]['BON'] += b''.join([PackVector('f', [b for b,w in skinning[loops[l].vertex_index]]) for l in mtlloops])
                mtlvbs[mtlname]['WEI'] += b''.join([PackVector('f', [w for b,w in skinning[loops[l].vertex_index]]) for l in mtlloops])
                
                for vclyr in obj.data.color_attributes:
                    if vclyr.name not in mtlvbs[mtlname].keys():
                        mtlvbs[mtlname][vclyr.name] = b''
                    mtlvbs[mtlname][vclyr.name] += b''.join([PackVector('B', [int(x*255) for x in vclyr.data[l].color]) for l in mtlloops])
                for uvlyr in obj.data.uv_layers:
                    if uvlyr.name not in mtlvbs[mtlname].keys():
                        mtlvbs[mtlname][uvlyr.name] = b''
                    mtlvbs[mtlname][uvlyr.name] += b''.join([PackVector('f', uvlyr.uv[l].vector) for l in mtlloops])
                
        if src.vbm.get('VBM_DATA'+checksum_key, None):
            del src.vbm['VBM_DATA'+checksum_key]
        src.vbm['VBM_DATA'+checksum_key] = {mtlname: {streamkey: zlib.compress(stream) for streamkey,stream in streams.items()} for mtlname,streams in mtlvbs.items()}
        src.vbm['VBM_CHECKSUM'+checksum_key] = checksum
    return {mtlname: {streamkey: zlib.decompress(streamcompressed) for streamkey,streamcompressed in mtlstreams.items()} for mtlname,mtlstreams in src.vbm['VBM_DATA'+checksum_key].items()}

def AnimData(action, rig):
    if not rig:
        return {}
    
    checksum = sum(np.array([x for x in (
        [action.vbm.clean_on_bake] +
        [x for fc in action.fcurves for k in fc.keyframe_points for x in k.co] +
        ([x for b in rig.data.bones for v in (b.head_local, b.tail_local) for x in v] if rig else []) +
        ([i*ord(x) for i,bname in enumerate(EvaluateDeformOrder(rig)[0]) for x in bname] if rig else [])
    )]).tobytes() )
    if action.vbm.get('VBM_CHECKSUM', -1) != checksum:
        # Make Proxy
        context = bpy.context
        deformorder, deformmap, deformroute = EvaluateDeformOrder(rig)
        
        proxy = bpy.data.objects.get(rig.vbm.get('PROXY', ""), None)
        if not proxy:
            proxy = bpy.data.objects.new(name="PROXY_"+rig.name, object_data=bpy.data.armatures.new(name="PROXY_"+rig.name))
            proxy['TEMP'] = True
            proxy.data['TEMP'] = True
            context.scene.collection.objects.link(proxy)
            proxy.show_in_front=True
            context.view_layer.objects.active = proxy
            proxy.animation_data_create()
            
            bpy.ops.object.mode_set(mode='OBJECT')
            bonedata = [
                (b.name, b.head_local, b.tail_local, b.AxisRollFromMatrix(b.matrix_local.to_3x3())[1], b.use_connect) 
                for bname in deformorder if bname in rig.data.bones.keys() for b in [rig.data.bones[bname]]
            ]
            
            proxy.select_set(True)
            bpy.ops.object.mode_set(mode='EDIT')
            for bname, head, tail, roll, use_connect in bonedata:
                b = proxy.data.edit_bones.new(name=bname)
                b.head, b.tail, b.roll = (head,tail,roll)
                b.parent = proxy.data.edit_bones[deformmap[bname]] if deformmap.get(bname, None) in list(proxy.data.edit_bones.keys()) else None
                b.use_connect = use_connect
            bpy.ops.object.mode_set(mode='POSE')
            rig.vbm['PROXY'] = proxy.name
        
        # Bake Animation
        print("> Baking animation", action.name)
        
        [obj.select_set(False) for obj in context.selected_objects]
        context.view_layer.objects.active = proxy
        proxy.select_set(True)
        proxy.animation_data.action = bpy.data.actions.new(action.name+"__deform")
        proxy.animation_data.action['TEMP'] = True
        
        rig.animation_data.action = action
        rig.animation_data.action_slot = action.slots[0]
        rig.data.pose_position = 'POSE'
        proxy.data.pose_position = 'POSE'
        
        bpy.ops.object.mode_set(mode='POSE')
        for pb in rig.pose.bones:
            pb.location = (0,0,0)
            pb.rotation_quaternion = (1,0,0,0)
            pb.scale = (1,1,1)
        for pb in proxy.pose.bones:
            c = pb.constraints.new(type='COPY_TRANSFORMS')
            c.target = rig
            c.subtarget = pb.name
            
        bpy.ops.nla.bake(
            frame_start=int(action.frame_range[0]), frame_end=int(action.frame_range[1]+1), step=1, 
            only_selected=False, visual_keying=True, clear_constraints=True, clear_parents=False, 
            use_current_action=True, clean_curves=action.vbm.clean_on_bake, 
            bake_types={'POSE'}, channel_types={'LOCATION', 'ROTATION', 'SCALE'}
        )
        
        fcurves = proxy.animation_data.action.fcurves
        bonefcurves = {
            bname: (
                fcurves.find("pose.bones[\"%s\"].location" % bname, index=0),
                fcurves.find("pose.bones[\"%s\"].location" % bname, index=1),
                fcurves.find("pose.bones[\"%s\"].location" % bname, index=2),
                fcurves.find("pose.bones[\"%s\"].rotation_quaternion" % bname, index=0),
                fcurves.find("pose.bones[\"%s\"].rotation_quaternion" % bname, index=1),
                fcurves.find("pose.bones[\"%s\"].rotation_quaternion" % bname, index=2),
                fcurves.find("pose.bones[\"%s\"].rotation_quaternion" % bname, index=3),
                fcurves.find("pose.bones[\"%s\"].scale" % bname, index=0),
                fcurves.find("pose.bones[\"%s\"].scale" % bname, index=1),
                fcurves.find("pose.bones[\"%s\"].scale" % bname, index=2),
            )
            for bname in deformorder
        }
        
        curvesbone = {
            bname: [ [(k.co[0]-action.frame_start, k.co[1]) for k in fc.keyframe_points] if fc else [] for fc in bonechannels]
            for bname, bonechannels in bonefcurves.items()
        }
        
        if action.vbm.get('VBM_DATA', None):
            del action.vbm['VBM_DATA']
        action.vbm['VBM_DATA'] = curvesbone
        action.vbm['VBM_CHECKSUM'] = checksum
    
    return {
        curvename: tuple([
            tuple([
                tuple(k) for k in channel   # Keyframes
            ])
            for channel in curvedata    # Channels
        ])
        for curvename, curvedata in action.vbm['VBM_DATA'].items()    # Curves
    }

def ImageData(image, palette_max=255):
    if image.has_data:
        checksum = sum(tuple(image.pixels)) + palette_max + image.size[0] + image.size[1]
        if image.vbm.get('VBM_CHECKSUM', -1) != checksum:
            srcpixels = np.frombuffer((np.array(image.pixels)*255).astype(np.uint8).tobytes(), dtype=np.uint32)
            w,h = image.size
            srcpixels = srcpixels.reshape(-1,w)[::-1].flatten()     # Flip image pixels
            pixels = srcpixels[:]
            palette = list(set(pixels))
            
            # Reduce number of colors while palette count is higher than max
            n1 = len(palette)
            if n1 > 0:
                # Old Method
                if w*h >= 1024*1024:
                    p = 1
                    pbytes = np.array(tuple(pixels.tobytes()), dtype=np.uint8)
                    if image.alpha_mode == 'NONE':
                        pbytes |= 0xFF000000
                    while len(palette) >= palette_max:
                        p += 1
                        pixels = np.frombuffer((pbytes // p) * p, dtype=np.uint32)
                        palette = list(set(pixels))
                    print(image.name, "| Palette ", n1, "->", len(palette), "| P =", p)
                # Palette Map, maintaining colors used in image
                elif len(palette) < palette_max:
                    newpixels = pixels
                    srcpalette = np.unique(pixels)
                    for pmask in (0xf7f7f7f7, 0xf0f0f0f0, 0xaaaaaaaa, 0xa2a2a2a2, 0x88888888):
                        print(HexString(pmask, 8))
                        palette_map = { x&pmask: i for i,x in enumerate(srcpalette) }
                        newpixels = tuple([srcpalette[ palette_map[x&pmask] ] for x in pixels])
                        palette = list(set(newpixels))
                        if len(palette) < palette_max:
                            break
                    pixels = newpixels
                    
            palette.sort()
            palette = tuple(palette)
            indices = [palette.index(x) for x in pixels]
            
            image.vbm['VBM_DATA'] = (zlib.compress(np.array(palette, dtype=np.uint32)), zlib.compress(np.array(indices, dtype=np.uint32)), tuple(image.size))
            image.vbm['VBM_CHECKSUM'] = checksum
    else:
        print("! Image \"%s\" had no data!" % (image.name if image else "(None)"), len(image.vbm.get('VBM_DATA', [None, None])))
    
    if image.vbm.get('VBM_DATA', None):
        palette = np.frombuffer( zlib.decompress(image.vbm['VBM_DATA'][0]), dtype=np.uint32 )
        indices = np.frombuffer( zlib.decompress(image.vbm['VBM_DATA'][1]), dtype=np.uint32 )
        width, height = image.vbm.get('VBM_DATA', [0,0,image.size])[2] if len(image.vbm['VBM_DATA']) >= 3 else image.size
    else:
        palette = [0]
        indices = [0]*image.size[0]*image.size[1]
        width, height = image.vbm.get('VBM_DATA', [0,0,image.size])[2]
    
    if ( image.alpha_mode.upper() == 'NONE' ):
        palette = palette | 0xFF000000
    return (palette, indices, (width, height))

# ===================================================================================================================
def ExportModel(collection, report=True):
    print("> Exporting model \"%s\" ***********************************************************************" % collection.name)
    
    context = bpy.context
    Clean()
    
    collectionobjects = [x for x in collection.objects]
    meshobjects = [x for x in collection.objects if x.type=='MESH' and ValidName(x.name)]
    
    action_pose = collection.vbm.action_pose
    rig = ([obj for obj in collection.all_objects if obj.type=='ARMATURE' and len(obj.children) > 0]+[None])[0]
    deformorder, deformmap, deformroute = EvaluateDeformOrder(rig)
    
    last_active_object = context.active_object
    last_rig_action = rig.animation_data.action if rig and rig.animation_data else None
    last_rig_position = rig.data.pose_position if rig else None
    
    format = collection.vbm.format
    format_mask = sum([1<<i for i,x in enumerate(format) if x]) // 1
    stride = CalcStride(format_mask)
    
    apply_transform = rig != None
    
    if ((1<<VFORMAT_INDEX['BON']) & format_mask==0) and ((1<<VFORMAT_INDEX['WEI']) & format_mask==0):
        pass
    
    bone_group_source_collection = collection
    if rig and len(collection.vbm.bone_groups) == 0:
        bone_group_source_collection = rig.users_collection[0]
    bone_groups = bone_group_source_collection.vbm.bone_groups
    
    palette_max = 1024
    compress_texture = False
    
    print("\t%02dB:"%stride, [VFORMAT_NAME[i] for i in range(0,16) if format_mask&(1<<i)])
    
    meshitems = []
    collisionitems = []
    boneitems = []
    materialitems = []
    textureitems = []
    animationitems = []
    node_names = []
    
    modeldata = {k: [] for k in 'NAM VTX MSH PSM SKE TEX MTL ANI'.split()}
    chunkversionmap = {}
    
    chunkversionmap['VTX'] = 1
    
    # Objects -------------------------------------------------------------------------------
    vbmap = {}
    material_names = []
    
    def ExportModel_WalkObjects(state, parent_index, objects, depth=0):
        vbmap = state['vbmap']
        modeldata = state['modeldata']
        format_mask = state['format_mask']
        filecollection = state['collection']
        material_names = state['material_names']
        node_names = state['node_names']
        
        object_script_pre = filecollection.vbm.object_script_pre
        object_script_post = filecollection.vbm.object_script_post
        
        use_material_names = filecollection.vbm.use_material_names
        mesh_join_names = filecollection.vbm.mesh_join_names
        
        objects = list(objects)
        for obj in objects:
            if not ValidName(obj.name):
                continue
            if not obj.vbm.export_enabled:
                continue
            
            node_enabled = 1
            node_index = len(modeldata['SKE'])
            node_meshes = []
            layermask = sum([1<<i for i,x in enumerate(obj.vbm.layermask) if x])
            
            if obj.type in VBM_MESHTYPES:
                # Prism .....................................................
                if obj.vbm.is_collision:
                    vb = b''
                    for mtlname, mtlstreams in MeshData(obj, apply_transform=apply_transform, rig=rig).items():
                        vb += mtlstreams['POS']
                    
                    coords = ([Vector(Unpack('fff', vb[i:i+12])) for i in range(0, len(vb), VFORMAT_SPACE[0])])
                    bounds = (
                        tuple([min([v[i] for v in coords]) for i in (0,1,2)]),
                        tuple([max([v[i] for v in coords]) for i in (0,1,2)])
                    )
                    loop_count = len(coords)
                    triangle_count = loop_count // 3
                    
                    flags = (
                        0
                    )
                    
                    collisionbin = b''
                    collisionbin += Pack('i', flags)
                    collisionbin += Pack('i', ~0 if rig else node_index)    # Node Index
                    collisionbin += Pack('i', len(coords))
                    collisionbin += b''.join([PackVector('f', v) for v in coords])
                    modeldata['PSM'].append(collisionbin)
                
                # Mesh .......................................................
                else:
                    mtlvbs = MeshData(
                        obj, 
                        apply_transform=apply_transform, 
                        rig=rig, 
                        action_pose=action_pose, 
                        object_script_pre=object_script_pre, 
                        object_script_post=object_script_post
                    ).items()
                    
                    for mtlname,mtlstreams in mtlvbs:
                        # Fix name
                        meshname = obj.name.split("/")[-1]
                        if mesh_join_names:
                            meshname = meshname.split(".")[0]
                        if use_material_names:
                            meshname += "_"+mtlname
                        meshname = FixName(meshname)
                        
                        # TODO: Properly code mesh ->node grouping
                        if meshname not in list(vbmap.keys()):
                            vbmap[meshname] = {'vb': b'', 'material': mtlname, 'node_index': node_index, 'layermask': layermask}
                            #print([meshname, node_index])
                        
                        if mtlname not in material_names:
                            material_names.append(mtlname)
                        if obj.users_collection:
                            for item in obj.users_collection[0].vbm.material_overrides:
                                if item.material and not item.override:
                                    if item.material.name not in material_names:
                                        material_names.append(item.material.name)
                        
                        loop_count = len(mtlstreams['POS']) // 12
                        
                        streams = []
                        streamspaces = []
                        for a in range(0, 10):
                            if format_mask & (1<<a):
                                stream = mtlstreams[VFORMAT_NAME[a]]
                                space = VFORMAT_SPACE[a]
                                isbyte = (format_mask & (1<<(a+16))) != 0
                                
                                # Normals
                                if VFORMAT_NAME[a] == 'NOR':
                                    stream = mtlstreams['NOR']
                                    if isbyte:
                                        padding = [0]
                                        stream = b''.join([PackVector('B', [int(255*(x*0.5+0.5)) for x in Unpack('fff', stream[l*12:(l+1)*12])]+padding) for l in range(0, loop_count)])
                                        space = 4
                                # Use given color layer
                                elif VFORMAT_NAME[a] == 'COL':
                                    if collection.vbm.color_layer_name:
                                        if collection.vbm.color_layer_name in mtlstreams.keys():
                                            stream = mtlstreams[collection.vbm.color_layer_name]
                                        else:
                                            stream = PackVector('B', [int(255*x) for x in collection.vbm.color_layer_default])*loop_count
                                    
                                    # Gamma correct
                                    if collection.vbm.color_is_srgb:
                                        stream = np.array([int(min( 255.0*((x/255.0)**0.4545) , 255)) for x in stream], dtype=np.uint8).tobytes()
                                    space = 4
                                    if not isbyte:
                                        stream = (np.array(tuple(stream), np.float32)/255.0).tobytes()
                                        space = 4*4
                                # Use given UV layer
                                elif VFORMAT_NAME[a] == 'UVS':
                                    if collection.vbm.uv_layer_name:
                                        if collection.vbm.uv_layer_name in mtlstreams.keys():
                                            stream = (mtlstreams[collection.vbm.uv_layer_name])
                                        else:
                                            stream = (PackVector('f', collection.vbm.uv_layer_default)*loop_count)
                                        
                                    if isbyte:
                                        padding = [0,0]
                                        stream = b''.join([PackVector('B', [int(255*x) for x in Unpack('ff', stream[l*8:(l+1)*8])]+padding) for l in range(0, loop_count)])
                                        space = 4
                                # Bones, Weights
                                elif VFORMAT_NAME[a] == 'BON':
                                    stream = mtlstreams[VFORMAT_NAME[a]]
                                    if isbyte:
                                        stream = b''.join([PackVector('B', [int(x) for x in Unpack('ffff', stream[l*16:(l+1)*16])]) for l in range(0, loop_count)])
                                        space = 4
                                elif VFORMAT_NAME[a] == 'WEI':
                                    stream = mtlstreams[VFORMAT_NAME[a]]
                                    if isbyte:
                                        stream = b''.join([PackVector('B', [int(x*255.0) for x in Unpack('ffff', stream[l*16:(l+1)*16])]) for l in range(0, loop_count)])
                                        space = 4
                                # Other attribute
                                else:
                                    stream = mtlstreams[VFORMAT_NAME[a]]
                                streams.append(stream)
                                streamspaces.append(space)
                        
                        vb = b''.join(tuple([
                            streams[a][l*space:(l+1)*space]
                            for l in range(0, loop_count)
                            for a,space in enumerate(streamspaces)
                        ]))
                        vbmap[meshname]['vb'] += vb
            
            if node_enabled:
                flags = 0
                bonebin = b''
                bonebin += Pack('i', flags)         # Flags
                bonebin += Pack('i', layermask)     # Layermask
                bonebin += PackMatrix(Matrix.Identity(4) if apply_transform else obj.matrix_world)    # Bind Matrix
                bonebin += Pack('i', parent_index)                    # Parent Index
                bonebin += PackString(FixName(obj.name.split("/")[-1]))     # Name
                
                node_names.append(obj.name)
                modeldata['SKE'].append(bonebin)
            ExportModel_WalkObjects(state, node_index, obj.children, depth+1)
        return state
    
    walkobjects = list(collection.objects)
    def ExportModel_WalkCollection(objects, collection):
        for c in collection.children:
            if ValidName(c.name) and not c.vbm.enabled:
                objects += list(c.objects)
                ExportModel_WalkCollection(objects, c)
    ExportModel_WalkCollection(walkobjects, collection)
    
    walkstate = ExportModel_WalkObjects(
        {
            'collection': collection, 
            'vbmap': vbmap, 
            'modeldata':modeldata, 
            'vb':b'', 
            'format': format, 
            'format_mask': format_mask, 
            'material_names':material_names,
            'node_names':node_names,
            'actions': animationitems
        }, 
        ~0, 
        [x for x in walkobjects if not x.parent]
    )
    
    netvb = b''
    
    # Meshes ------------------------------------------------------------------------------
    mesh_index = 0
    for meshname, meshdata in list(vbmap.items()):
        mtlname = meshdata['material']
        vb = meshdata['vb']
        node_index = meshdata['node_index']
        layermask = meshdata['layermask']
        
        loop_count = len(vb) // stride
        loop_offset = len(netvb) // stride
        
        flags = 0
        #print("\tMSH [%6d: %6d] %16s | Mtl: \"%s\"" % (loop_offset, loop_offset+loop_count, meshname, mtlname))
        
        coords = ([Vector(Unpack('fff', vb[i:i+12])) for i in range(0, len(vb), stride)])
        bounds = (
            tuple([min([v[i] for v in coords]) for i in (0,1,2)]),
            tuple([max([v[i] for v in coords]) for i in (0,1,2)])
        )
        
        meshbin = b''
        meshbin += Pack('i', flags)     # Flags
        meshbin += Pack('i', layermask)     # Layermask
        meshbin += PackString(meshname)     # Mesh name
        meshbin += Pack('i', ~0 if rig else node_index)    # Node Index
        meshbin += Pack('i', material_names.index(mtlname))     # Material Index
        meshbin += Pack('i', loop_offset)     # Loop Start
        meshbin += Pack('i', loop_count)     # Loop Count
        meshbin += PackVector('f', bounds[0]) + PackVector('f', bounds[1])     # Bounds
        modeldata['MSH'].append(meshbin)
        
        #print("[%2d]: %s .bone = %d [%s]" % (mesh_index, meshname, node_index, node_names[node_index]))
        
        netvb += vb
        mesh_index += 1
    
    # Bones -------------------------------------------------------------------------------
    if rig:
        modeldata['SKE'] = []
        deformorder, deformmap, deformroute = EvaluateDeformOrder(rig)
        
        parent_index_last = 255
        parent_switches = 0
        switched = 0
        
        for bname in deformorder:
            layermask = bone_group_source_collection.vbm.get_bone_layermask(bname)
            bone_group = ([bgroup for bgroup in bone_groups if bname in list(bgroup.bones.keys())]+[None])[0]
            flags = (
                (VBM_BONEFLAGS_SWINGBONE if bone_group and bone_group.swing_enabled else 0)
            )
            
            parent_index = deformorder.index(deformmap[bname]) if deformmap[bname] else ~0
            parent_switches += (parent_index != parent_index_last)
            switched = (parent_index != parent_index_last)
            parent_index_last = parent_index
            
            b = rig.data.bones.get(bname, None)
            bonebin = b''
            bonebin += Pack('i', flags)             # Flags
            bonebin += Pack('i', layermask)         # Layermask
            bonebin += PackMatrix(b.matrix_local if b else Matrix.Identity(4))  # Bind Matrix
            bonebin += Pack('i', parent_index)    # Parent Node Index
            bonebin += PackString(FixName(bname))   # Node Name
            
            BoneDepth = lambda bname, deformmap: (1+BoneDepth(deformmap[bname], deformmap)) if deformmap[bname] else 0
            #print("[%3d ^ %3d] %s %s%s" % (len(modeldata['SKE']), parent_index, " !"[switched], "| "*BoneDepth(bname, deformmap), bname))
            
            if flags & VBM_BONEFLAGS_SWINGBONE:
                bonebin += Pack('f', bone_group.stiffness)
                bonebin += Pack('f', bone_group.damping)
                bonebin += Pack('f', bone_group.limit)
                bonebin += Pack('f', bone_group.force_strength)
            
            modeldata['SKE'].append(bonebin)
        #print("Switches:", parent_switches)
    
    # Materials --------------------------------------------------------------------------
    texturenames = []
    material_names = material_names
    for mtlname in material_names:
        mtl = bpy.data.materials.get(mtlname, None)
        if not mtl:
            continue
        
        mtl = collection.vbm.get_material_override(mtl)
        flags = (
            VBM_MATERIALFLAGS_TRANSPARENT * (mtl.vbm.transparent) |
            VBM_MATERIALFLAGS_USECULLING * (mtl.use_backface_culling)
        )
        
        texturenodes = [nd for nd in mtl.node_tree.nodes if ValidName(nd.name) and nd.bl_idname=='ShaderNodeTexImage' and nd.image and ValidName(nd.image.name)]
        texturenodes.sort(key=lambda nd: -nd.location[1] if nd else 1000000000000)
        for nd in texturenodes:
            if nd.image.name not in texturenames:
                texturenames.append(nd.image.name)
        texturenodes = (texturenodes+[None]*4)[:4]
        
        mtlbin = b''
        mtlbin += Pack('i', flags)
        mtlbin += PackString(mtl.vbm.shader)  # Shader Name
        
        # 4 Textures max
        for texturenode in texturenodes:
            if texturenode:
                texflags = (
                    (VBM_TEXTUREFLAG_FILTERLINEAR * (texturenode.interpolation.upper() != 'CLOSEST')) |
                    (VBM_TEXTUREFLAG_EXTEND * (texturenode.interpolation=='EXTEND'))
                )
            else:
                texflags = 0
            mtlbin += Pack('i', texflags)  # Texture Flags
            mtlbin += Pack('i', texturenames.index(texturenode.image.name) if texturenode else 0)   # Texture Index
            mtlbin += PackString(texturenode.image.name if texturenode else "")  # Texture Name
        modeldata['MTL'].append(mtlbin)
    
    # Images --------------------------------------------------------------------------------
    for texturename in texturenames:
        image = bpy.data.images.get(texturename)
        
        if image:
            palette, indices, size = ImageData(image, palette_max)
            w,h = size
            index_dtype = 'H' if len(palette) >= 256 else 'B'
            
            imagebin = b''
            imagebin += Pack('III', w, h, len(palette))
            imagebin += PackVector('I', palette)
            
            # Switch data type based on palette count
            imagebin += PackVector(index_dtype, indices)
            modeldata['TEX'].append(imagebin)
    
    # Actions -----------------------------------------------------------------------------
    Clean()
    for actionitem in collection.vbm.actions:
        if not actionitem.export_enabled:
            continue
        
        action = actionitem.action
        actionname = action.name
        
        if 1:
            actionname = actionname.split("/")[-1]
        
        bonemask = int(sum([1<<i for i,x in enumerate(action.vbm.layermask) if x]))
        
        bonedata = AnimData(action, rig)
        bonedata = {bname: curves for bname,curves in bonedata.items() if bone_group_source_collection.vbm.get_bone_layermask(bname) & bonemask}
        
        propcurves = [fc for fc in action.fcurves if "pose.bones" not in fc.data_path]
        propdata = {fc.data_path: [] for fc in propcurves}
        [propdata[fc.data_path].append([tuple(k.co) for k in fc.keyframe_points]) for fc in propcurves]
        propdata = { k.split("\"")[1] if "\"" in k else k :channels for k,channels in propdata.items() }
        
        curvedata = {name:channels for name,channels in list(bonedata.items())+list(propdata.items())}
        
        frame_start = int(action.frame_range[0])
        frame_end = int(action.frame_range[1])
        frame_rate = int(action.vbm.frame_rate)
        flags = (
            ( VBM_ANIMATIONFLAGS_CURVENAMES * 1 ) | # Curve names
            ( VBM_ANIMATIONFLAGS_CURVELOOP * action.use_cyclic ) |  # Curve Loop
            ( VBM_ANIMATIONFLAGS_MARKERS * (len(action.pose_markers) > 0) )  # Curve Markers
        )
        
        outaction = b''
        outaction += Pack('BBB', *[ord(c) for c in "ANI"])+Pack('B', 0)  # Version
        outaction += Pack('i', flags)  # Flags
        outaction += PackString(FixName(actionname))  # Name
        outaction += Pack('i', int((action.frame_end-action.frame_start+1)))     # Duration
        outaction += Pack('i', context.scene.render.fps)     # FPS
        outaction += Pack('i', 0)     # Loop Point
        outaction += Pack('i', len(curvedata.values()))  # Curve Count
        outaction += Pack('i', sum([len(curve) for curve in curvedata.values()]))  # Channel Count
        outaction += Pack('i', sum([len(channel) for curve in curvedata.values() for channel in curve]))  # Keyframe Count
        outaction += Pack('i', len(bonedata.values()))  # Props View Index / Number of bone curves
        
        # Pose Markers
        if ( flags & VBM_ANIMATIONFLAGS_MARKERS ):
            outaction += Pack('i', len(action.pose_markers))
            for m in action.pose_markers:
                outaction += PackString(m.name)     # Marker Name
                outaction += Pack('f', m.frame)     # Marker Frame
        
        # Bone Curves + Property Curves 
        curve_index = 0
        for curvename, channels in curvedata.items():
            if flags & VBM_ANIMATIONFLAGS_CURVENAMES:
                outaction += PackString(FixName(curvename))  # Curvename
            outaction += Pack('i', len(channels)) # Channel count
            for channel in channels:
                outaction += Pack('i', len(channel)) # Keyframe count
                for k in channel:
                    #print(action.name, k, [x for x in k])
                    outaction += Pack('f', k[0])    # Frame
                    outaction += Pack('f', k[1])    # Value
            curve_index += 1
        
        modeldata['ANI'].append(outaction)
        collection.vbm.action_index = collection.vbm.action_index
    
    # Vertex Buffer --------------------------------------------------------------
    compress_vertex_buffer = collection.vbm.use_vtx_compression != 0
    
    buffer_size = len(netvb)
    loop_count = len(netvb) // stride
    
    flags = (
        (VBM_VTX_COMPRESSED * compress_vertex_buffer)
    )
    
    outvtx = b''
    outvtx += Pack('I', flags)
    outvtx += Pack('I', format_mask)
    outvtx += Pack('I', buffer_size)
    
    if not compress_vertex_buffer:
        outvtx += netvb
    else:
        # TODO: Make mesh checksum key at start of export function for use here
        checksum = -1
        
        if checksum < 0:
            attribute_types = [i for i in range(0, 16) if format_mask&(1<<i)]
            attribute_isbyte = [ (format_mask&(1<<(a+16))) != 0 for a in attribute_types ]
            attribute_spaces = [4 if attribute_isbyte[i] else VFORMAT_SPACE[a] for i,a in enumerate(attribute_types)]
            attribute_vectors = []
            attribute_count = len(attribute_types)
            offset = 0
            
            floatmask = 0xFFFF_FF00     # Lower bits are mantissa. Removing them lowers precision, but makes attribute set smaller
            for a,space in enumerate(attribute_spaces):
                if not attribute_isbyte[a]:
                    stream = np.frombuffer(b''.join([netvb[o:o+space] for o in range(offset, buffer_size, stride)]), dtype=np.uint32) & floatmask
                    stream = stream.tobytes()
                    stream = tuple([ stream[o:o+space] for o in range(0, len(stream), space)])
                else:
                    stream = tuple([( netvb[o:o+space]) for o in range(offset, buffer_size, stride)])
                
                attribute_vectors.append(stream)
                offset += space
            attribute_sets = [ tuple(set(v)) for v in attribute_vectors ]
            
            indices = [attribute_sets[a].index(attribute_vectors[a][l]) for l in range(0, loop_count) for a in range(0, attribute_count)]
            #print(len(indices), stride, loop_count, buffer_size, attribute_spaces, [len(x) for x in attribute_vectors], [len(x) for x in attribute_sets])
            
            if collection.vbm.get('VBM_DATA', None):
                del collection.vbm['VBM_DATA']
            collection.vbm['VBM_DATA'] = (attribute_sets, indices)
            #collection.vbm['VBM_CHECKSUM'] = checksum
        
        attribute_sets, indices = collection.vbm['VBM_DATA']
        
        outvtx += Pack('I', len(attribute_sets))   # Number of attributes
        for attribset in attribute_sets:
            outvtx += Pack('I', len(attribset))     # Attribute set size
            outvtx += Pack('I', len(attribset[0]))     # Attribute space
            outvtx += b''.join(attribset)           # Attribute set
        outvtx += b''.join([Pack('H', x) for x in indices])
    
    # Output ------------------------------------------------------------------------------
    Clean()
    
    context.view_layer.objects.active = last_active_object
    if rig and rig.animation_data:
        rig.animation_data.action = last_rig_action
        rig.data.pose_position = last_rig_position
    
    if len(netvb) == 0:
        print("! WARNING: Length of vertex buffer == 0")
    
    modeldata['NAM'] = PackString(FixName(collection.name))                 # Model Name
    modeldata['VTX'] = outvtx
    modeldata['END'] = Pack('I', 0)  # End chunk
    
    print([", ".join([ (("%s[%d]" % (type, len(data)))) if isinstance(data, list) else "{%s}"%type for type,data in modeldata.items() if data])])
    
    modelchunks = {
        chunktype: ((Pack('I', len(data)) + b''.join(data)) if isinstance(data, list) else data)
        for chunktype, data in modeldata.items() if data
    }
    
    modelbin = PackChars("VBM") + Pack('B', 5) + b''.join([
        PackString(chunktype)[:3] +             # Type
        Pack('B',chunkversionmap.get(chunktype, 0)) +  # Version
        Pack('I', len(chunk)) +                 # Length
        chunk                                   # Data
        for chunktype, chunk in modelchunks.items() 
    ])
    
    # Compress
    if collection.vbm.use_compression:
        modelbin = zlib.compress(modelbin)
    
    # Write to file
    if context.scene.vbm.data_path:
        filepath = bpy.path.abspath(context.scene.vbm.data_path)
    else:
        filepath = bpy.path.abspath("/")
    
    if filepath[-1] not in "/\\":
        filepath += "/"
    filepath = filepath + FixName(os.path.splitext(collection.vbm.get_name())[0]) + VBM_FILEEXT
    
    f = open(os.path.abspath(bpy.path.abspath(filepath)), "wb")
    f.write(modelbin)
    f.close()
    
    print("< File written to \"%s\" (%4.4f MB)" % (("..." if len(filepath) > 64 else "")+filepath[-64:], len(modelbin)/1_000_000))
    print()

"======================================================================================================"
"REGISTER"
"======================================================================================================"

def register():
    [bpy.utils.register_class(c) for c in classlist]
    bpy.types.Collection.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Collection)
    bpy.types.Scene.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Scene)
    bpy.types.Material.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Material)
    bpy.types.Action.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Action)
    
    bpy.types.Object.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Object)
    bpy.types.Image.vbm = PointerProperty(name="DmrVBM", type=VBM_PG_Image)
    #bpy.types.SpaceView3D.draw_handler_add(vbm_draw_gpu, (), 'WINDOW', 'POST_VIEW')
    
def unregister():
    [bpy.utils.unregister_class(c) for c in classlist[::-1]]
    
if __name__ == "__main__":
    register()

