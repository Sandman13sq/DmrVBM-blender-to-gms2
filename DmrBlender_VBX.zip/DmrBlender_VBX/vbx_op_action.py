import bpy
import struct
import zlib
import sys

from bpy_extras.io_utils import ExportHelper
from struct import pack as Pack

PackString = lambda x: b'%c%s' % (len(x), str.encode(x))
PackVector = lambda v: b''.join([struct.pack('<f', x) for x in v])
PackMatrix = lambda m: b''.join( [struct.pack('<ffff', *x) for x in m.copy().transposed()] )
QuatValid = lambda q: q if q.magnitude != 0.0 else [1.0, 0.0, 0.0, 0.00001]

ANIVERSION = 1

"""
    header = 'ANI<version>'
    
    flag
        1<<0 = Frames are normalized
    maxframe
    trackcount
    tracknames[trackcount]
    trackdata[trackcount]
        location_framecount
        location_framepositions[location_framecount]
        location_vectors[location_framecount]
            vector[3]
        
        quaternion_framecount
        quaternion_framepositions[quaternion_framecount]
        quaternion_vectors[quaternion_framecount]
            vector[4]
        
        scale_framecount
        scale_framepositions[scale_framecount]
        scale_vectors[scale_framecount]
            vector[3]
    
    markercount
    markernames[markercount]
    markerframepositions[markercount]
    
"""

# =============================================================================

def Items_GetActions(self, context):
    return [
        (a.name, a.name, 'Export "%s"' % a.name, 'ACTION', i)
        for i, a in enumerate(bpy.data.actions)
    ]

def Items_GetArmatureObjects(self, context):
    return [
        (a.name, a.name, '%s' % a.name, 'ARMATURE_DATA', i)
        for i, a in enumerate(bpy.data.objects) if a.type == 'ARMATURE'
    ]

def ChooseAction(self, context):
    action = bpy.data.actions[self.actionname]

classlist = []

# =============================================================================

class DMR_OP_VBX_ExportPoses(bpy.types.Operator, ExportHelper):
    """Exports current armature pose"""
    bl_idname = "dmr.gm_export_pose"
    bl_label = "Export Pose"
    
    filename_ext = ".pse"
    filter_glob: bpy.props.StringProperty(default="*.pse", options={'HIDDEN'}, maxlen=255)
    
    def execute(self, context):
        active = bpy.context.view_layer.objects.active
        settings = {
            'path' : self.filepath,
        }
        ExportPose( FetchArmature(active), settings )
        bpy.context.view_layer.objects.active = active
        self.report({'INFO'}, 'Data written to "%s"' % self.filepath)
        return {'FINISHED'}
classlist.append(DMR_OP_VBX_ExportPoses)

# =============================================================================

class DMR_OP_VBX_ExportActionArmature(bpy.types.Operator, ExportHelper):
    """Exports all poses in active object's Action/Pose Library"""
    bl_idname = "dmr.vbx_export_action_armature"
    bl_label = "Export Armature Action"
    bl_options = {'PRESET'}
    
    filename_ext = ".trk"
    filter_glob: bpy.props.StringProperty(default="*"+filename_ext, options={'HIDDEN'}, maxlen=255)
    
    armature_object: bpy.props.EnumProperty(
        name='Armature Object', items=Items_GetArmatureObjects, default=0,
        description='Armature object to use for pose matrices'
    )
    
    action_name: bpy.props.EnumProperty(
        name='Action', items=Items_GetActions, default=0,
        description='Action to export',
    )
    
    frame_range: bpy.props.IntVectorProperty(
        name='Frame Range', size=2, default=(1, 250),
        description='Range of keyframes to export',
    )
    
    bake_samples: bpy.props.IntProperty(
        name="Bake Steps",
        description="Sample curves so that every nth frame has a vector.\nSet to 0 for no baking",
        default=5, min=-1
    )
    
    start_from_zero: bpy.props.BoolProperty(
        name="Trim Empty Leading", default=True,
        description='Start writing from first keyframe instead of from "Frame Start"',
    )
    
    write_marker_names: bpy.props.BoolProperty(
        name="Write Marker Names", default=True,
        description="Write names of markers before track data",
    )
    
    normalize_frames: bpy.props.BoolProperty(
        name="Normalize Frames", default=True,
        description="Convert Frames to [0-1] range",
    )
    
    make_start_frame: bpy.props.BoolProperty(
        name="Starting Keyframe", default=True,
        description="Insert a keyframe at the start of the animation",
    )
    
    make_end_frame: bpy.props.BoolProperty(
        name="Ending Keyframe", default=False,
        description="Insert a keyframe at the end of the animation",
    )
    
    deform_only: bpy.props.BoolProperty(
        name="Deform Bones Only", default=True,
        description='Only export bones with the "Deform" box checked',
    )
    
    lastsimplify = -1
    
    @classmethod
    def poll(self, context):
        return bpy.data.actions
    
    def invoke(self, context, event):
        sc = context.scene
        self.lastsimplify = sc.render.use_simplify
        sc.render.use_simplify = True
        
        #self.framerange = (sc.frame_start, sc.frame_end)
        
        # Pre-set armature and action
        objs = [x for x in context.selected_objects if x.type == 'ARMATURE']
        objs += [x.find_armature() for x in context.selected_objects if x and x.find_armature()]
        if objs:
            for o in objs:
                if o.animation_data and o.animation_data.action:
                    self.armature_object = o.name
                    self.action_name = o.animation_data.action.name
                    break
                elif o.pose_library:
                    self.armature_object = o.name
                    self.action_name = o.pose_library.name
            
        context.window_manager.fileselect_add(self)
        
        return {'RUNNING_MODAL'}
    
    def cancel(self, context):
        context.scene.render.use_simplify = self.lastsimplify
    
    def draw(self, context):
        layout = self.layout
        
        c = layout.column()
        c.prop(self, 'armature_object')
        c.prop(self, 'action_name')
        c.row().prop(self, 'frame_range')
        c.prop(self, 'bake_samples')
        c.prop(self, 'start_from_zero')
        c.prop(self, 'write_marker_names')
        c.prop(self, 'normalize_frames')
        c.prop(self, 'make_start_frame')
        c.prop(self, 'make_end_frame')
        
    def execute(self, context):
        # Find Armature
        object = bpy.data.objects[self.armature_object]
        if not object:
            self.report({'WARNING'}, 'Invalid object')
            context.scene.render.use_simplify = self.lastsimplify
            return {'FINISHED'}
        if object.type != 'ARMATURE':
            self.report({'WARNING'}, 'Active object "%s" is not an armature' % object.name)
            context.scene.render.use_simplify = self.lastsimplify
            return {'FINISHED'}
        
        # Settings
        actionname = self.action_name
        samples = self.bake_samples
        startfromzero = self.start_from_zero
        normalizeframes = self.normalize_frames
        writemarkernames = self.write_marker_names
        makestartframe = self.make_start_frame
        makeendframe = self.make_end_frame
        framerange = self.frame_range
        
        #arealast = context.area.type
        #context.area.type = "VIEW_3D"
        
        # Find Last Action
        poselibonly = 0
        if not (object.animation_data and object.animation_data.action):
            lastaction = None
            poselibonly = 1
        else:
            lastaction = object.animation_data.action
        if not lastaction:
            lastaction = object.pose_library
        if not lastaction:
            self.report({'WARNING'}, '"%s" has no active Action' % object.name)
            context.scene.render.use_simplify = self.lastsimplify
            return {'FINISHED'}
        
        bones = object.data.bones
        prepose = [b.matrix_basis.copy() for b in object.pose.bones]
        action = bpy.data.actions[actionname]
        object.animation_data.action = action
        
        workingaction = None
        
        # Get sampled action
        if samples > 0:
            print('> Baking animation...')
            
            contexttype = bpy.context.area.type
            bpy.context.area.type = "DOPESHEET_EDITOR"
            
            oldactiondata = set([x for x in bpy.data.actions])
            
            bpy.ops.nla.bake(
                frame_start=action.frame_range[0], frame_end=action.frame_range[1], 
                step=samples,
                only_selected=False, 
                visual_keying=False, 
                clear_constraints=False, 
                clear_parents=False, 
                use_current_action=False, 
                clean_curves=True, 
                bake_types={'POSE'}
                )
            
            #bpy.ops.action.clean(channels=True) # Remove untouched channels
            #bpy.ops.action.clean(channels=False) # Simplify Animation
            
            bpy.context.area.type = contexttype
            action = object.animation_data.action
            action.name = lastaction.name + '__temp'
            object.animation_data.action = lastaction
            
            print('> Animation ready')
        else:
            workingaction = action.copy()
        
        workingaction.name += '__temp'
        
        fcurves = workingaction.fcurves
        #framerange = workingaction.frame_range
        frameoffset = -framerange[0] if startfromzero else 0
        framemax = framerange[1] + frameoffset
        
        transformnames = ['location', 'rotation_quaternion', 'scale']
        entryoffset = {'location': 0, 'rotation_quaternion': 3, 'scale': 7}
        bonecurvemap = { b.name: [None] * 10 for b in bones }
        
        # Grab all curves and sort by bone name
        for c in fcurves:
            pth = c.data_path
            bonename = pth[pth.find('"')+1 : pth.rfind('"')]
            if bonename in bonecurvemap.keys():
                transformname = pth[pth.rfind('.')+1:]
                if transformname in entryoffset.keys():
                    bonecurvemap[bonename][entryoffset[transformname] + c.array_index] = c
        
        # Make a snapshot of pose bones for every frame
        posebones = object.pose.bones
        posesnap = {}
        
        SnapPose = lambda : {
            #pb.name: (pb.location[:], pb.rotation_quaternion[:], pb.scale[:])
            pb.name: object.convert_space(
                pose_bone=pb, matrix=pb.matrix, from_space='POSE', to_space='LOCAL').decompose()
                for pb in posebones
            }
        
        if not poselibonly:
            for f in range(int(framerange[0]), int(framerange[1])):
                context.scene.frame_set(f)
                bpy.context.view_layer.update()
                posesnap[f] = SnapPose()
        else:
            lastobjectmode = bpy.context.active_object.mode
            bpy.ops.object.mode_set(mode = 'POSE') # Update selected
            
            selected = [b for b in bones if b.select]
            hidden = [b for b in bones if b.hide]
            for b in hidden:
                b.hide = False
            
            markers = workingaction.pose_markers
            bpy.ops.pose.select_all(workingaction='SELECT')
            for m in markers:
                print(m.name)
                bpy.ops.poselib.apply_pose(pose_index=m.frame)
                posesnap[m.frame] = SnapPose()
            bpy.ops.pose.select_all(workingaction='DESELECT')
            
            for b in hidden:
                b.hide = True
            for b in selected:
                b.select = True
            
            bpy.ops.object.mode_set(mode = lastobjectmode)
            
        
        # Compose data ------------------------------------------------------
        print('> Composing data...')
        
        out = b''
        
        out += b'TRK' + Pack('B', ANIVERSION)
        
        # Flag
        flag = 0
        if normalizeframes:
            flag |= 1<<0
        out += Pack('B', flag)
        
        render = context.scene.render
        view_layer = bpy.context.view_layer
        view_layer.update()
        scene = context.scene
        
        for obj in scene.objects:
            if obj.type == 'MESH':
                obj.data.update()
        
        out += Pack('f', render.fps) # Animation Framerate
        out += Pack('H', int(framemax) ) # Max animation frame
        out += Pack('H', len(bones)) # Bone Count
        
        # Write Track Names
        out += b''.join( [PackString(b.name) for b in bones] )
        
        # Track Data
        if poselibonly:
            print("> Pose library only")
        print('Action = "%s", Range: %s' % (workingaction.name, framerange))
        print('> Writing Tracks...')
        
        frame_map_old = render.frame_map_old
        #render.frame_map_old = render.frame_map_new / 10
        
        # Settings
        if samples < 0:
            samples = framerange[1]-framerange[0]
        
        targetbones = [posebones[b.name] for b in bones if (b.use_deform or not deformonly)]
        
        for b in targetbones: # For each bone (track)
            outchunk = b''
            transcurves = bonecurvemap[b.name]
            posebone = object.pose.bones[b.name]
            #print(b.name)
            
            transformtype = 0
            
            # For each transform (location[3], quat[4], scale[3])
            for vectorindices in tuple( tuple(0,1,2), tuple(3,4,5,6), tuple(7,8,9) ):
                # Grab transform curves using trackindices
                curveset = transcurves[vectorindices[0]:vectorindices[-1]+1]
                
                # Merge keyframe positions for each track in transform
                # [location[0].frames + location[1].frames + location[2].frames]
                trackframes = set([
                    k.co[0]
                    for curve in curveset
                    for k in (curve.keyframe_points if curve else [])
                ])
                
                if makestartframe:
                    trackframes.add(framerange[0])
                if makeendframe:
                    trackframes.add(framerange[1])
                    
                trackframes = list(trackframes)
                trackframes.sort()
                
                # Manual Sampling
                #"""
                if 0 and samples > 0 and len(trackframes) > 1:
                    newpts = []
                    for i in range(0, len(trackframes)-1):
                        p1 = trackframes[i]
                        p2 = trackframes[i+1]
                        step = (p2-p1) / samples
                        while p1 < p2:
                            newpts.append(p1)
                            p1 += step
                        newpts.append(p2)
                    newpts = list(set([round(x) for x in newpts]))
                    newpts.sort()
                    trackframes = newpts
                #"""
                outchunk += Pack('H', len(trackframes)) # Frame count
                
                # Write Frame Positions
                if normalizeframes: # Frame Positions are [0-1] range
                    outchunk += b''.join( Pack('f', (frame+frameoffset)/framemax) for frame in trackframes )
                else: # Frame positions are unchanged
                    outchunk += b''.join( Pack('f', frame+frameoffset) for frame in trackframes )
                
                # For each frame in track
                for f in trackframes:
                    if f not in posesnap.keys():
                        scene.frame_set(f)
                        view_layer.update()
                        posesnap[f] = {
                            #pb.name: (pb.location[:], pb.rotation_quaternion[:], pb.scale[:])
                            pb.name: object.convert_space(pose_bone=pb, matrix=pb.matrix, from_space='POSE', to_space='LOCAL').decompose()
                            for pb in posebones
                        }
                    
                    # Write Vector
                    outchunk += PackVector( posesnap[f][b.name][transformtype] )
                
                transformtype += 1
                 
            # Add chunk to output
            out += outchunk
        
        render.frame_map_old = frame_map_old
        
        # Write Marker Data
        if writemarkernames:
            print('> Writing Marker Data...')
            
            markers = [m for m in lastworkingaction.pose_markers]
            #markers.sort(key = lambda m: m.frame)
            
            out += Pack('H', len(markers))
            # Write Marker Names
            out += b''.join( [PackString(m.name) for m in markers] )
            # Write Marker Frame Positions
            if normalizeframes:
                out += b''.join( [Pack('f', (m.frame+frameoffset)/framemax) for m in markers] )
                for m in markers:
                    print("<%s: %.4f>" % (m.name, (m.frame+frameoffset)/framemax))
            else:
                out += b''.join( [Pack('f', m.frame+frameoffset) for m in markers] )
                for m in markers:
                    print("<%s: %.4f>" % (m.name, m.frame+frameoffset))
        else:
            out += Pack('H', 0)
        
        # Restore Previous State
        for i in range(0, len(object.pose.bones)):
            object.pose.bones[i].matrix_basis = prepose[i]
        #if poselibonly:
            #object.animation_data = None
        render.use_simplify = self.lastsimplify
        context.area.type = arealast
        
        bpy.data.actions.remove(workingaction)
        
        # Output to File
        oldlen = len(out)
        out = zlib.compress(out)
        
        file = open(self.filepath, 'wb')
        file.write(out)
        file.close()
        
        report = 'Data written to "%s". (%.2fKB -> %.2fKB) %.2f%%' % \
            (self.filepath, oldlen / 1000, len(out) / 1000, 100 * len(out) / oldlen)
        print(report)
        self.report({'INFO'}, report)
        return {'FINISHED'}
classlist.append(DMR_OP_VBX_ExportActionArmature)

# =============================================================================

class DMR_GM_ExportPoseMatrix(bpy.types.Operator, ExportHelper):
    """Exports all poses in active object's Action/Pose Library"""
    bl_idname = "dmr.gm_export_posematrix"
    bl_label = "Export Action"
    
    filename_ext = ".pse"
    filter_glob: bpy.props.StringProperty(default="*"+filename_ext, options={'HIDDEN'}, maxlen=255)
    
    def execute(self, context):
        # Find Armature ----------------------------------------------------
        object = bpy.context.object
        if not object:
            self.report({'WARNING'}, 'No object selected')
            return {'FINISHED'}
        if object.type != 'ARMATURE':
            self.report({'WARNING'}, 'Active object "%s" is not an armature' % object.name)
            return {'FINISHED'}
        
        # Setup Vars ----------------------------------------------------
        object = bpy.context.object
        bones = object.data.bones
        pbones = object.pose.bones
        prepose = [b.matrix_basis.copy() for b in pbones]
        
        action = object.pose_library
        markers = action.pose_markers
        print([(m.name, m.frame) for m in action.pose_markers])
        keyframes = [m.frame for m in action.pose_markers]
        #keyframes.sort(key = lambda x : x[1])
        keyframes.sort()
        
        # Get Poses ----------------------------------------------------
        out = b''
        
        out += Pack('<I', len(bones))
        out += Pack('<I', len(keyframes))
        
        # Store State
        lastobjectmode = bpy.context.active_object.mode
        bpy.ops.object.mode_set(mode = 'POSE') # Update selected
        selected = [b for b in bones if b.select]
        hidden = [b for b in bones if b.hide]
        
        for b in hidden: b.hide = False
        bpy.ops.pose.select_all(action='SELECT')
        
        # Pose iteration ===============================================
        for i in range(0, len(markers)):
            # Set pose
            bpy.ops.poselib.apply_pose(pose_index=i)
            chunk = b''
            # Write matrix data
            for pb in pbones:
                chunk += PackMatrix(pb.matrix_channel)
            out += chunk
            
        # Restore State ------------------------------------------------
        bpy.ops.pose.select_all(action='DESELECT')
        for b in selected: b.select = True
        for b in hidden: b.hide = True
        for i in range(0, len(pbones)):
            pbones[i].matrix_basis = prepose[i]
        bpy.ops.object.mode_set(mode = lastobjectmode)
        
        # Output to File ===============================================
        oldlen = len(out)
        out = zlib.compress(out)
        
        file = open(self.filepath, 'wb')
        file.write(out)
        file.close()
        
        report = 'Data written to "%s". (%.2fKB -> %.2fKB) %.2f%%' % \
            (self.filepath, oldlen / 1000, len(out) / 1000, 100 * len(out) / oldlen)
        print(report)
        self.report({'INFO'}, report)
        
        return {'FINISHED'}
classlist.append(DMR_GM_ExportPoseMatrix)      

def register():
    for c in classlist:
        bpy.utils.register_class(c)

def unregister():
    for c in reversed(classlist):
        bpy.utils.unregister_class(c)
